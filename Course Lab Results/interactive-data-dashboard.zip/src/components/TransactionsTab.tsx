import React, { useState, useMemo } from "react";
import { Transaction, parseCSVString, exportToCSVString } from "../data";
import { 
  Search, Plus, Trash2, ChevronLeft, ChevronRight, Download, Upload, 
  Filter, Calendar, DollarSign, Archive, X, Check, Save, FileSpreadsheet, RefreshCw
} from "lucide-react";

interface TransactionsTabProps {
  transactions: Transaction[];
  onAddTransaction: (t: Omit<Transaction, "id">) => void;
  onDeleteTransaction: (id: string) => void;
  onSetTransactions: (items: Transaction[]) => void;
  onRestoreDefaults: () => void;
}

export default function TransactionsTab({
  transactions,
  onAddTransaction,
  onDeleteTransaction,
  onSetTransactions,
  onRestoreDefaults
}: TransactionsTabProps) {
  
  // Search and Filtering State
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMethod, setSelectedMethod] = useState("");
  const [selectedProduct, setSelectedProduct] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  // Table Pagination & Sorting State
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [sortField, setSortField] = useState<keyof Transaction>("date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  // New Transaction Form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [newOrderNum, setNewOrderNum] = useState("");
  const [newProduct, setNewProduct] = useState("");
  const [newPrice, setNewPrice] = useState("");
  const [newDate, setNewDate] = useState("");
  const [newPaymentMethod, setNewPaymentMethod] = useState("Credit Card");
  
  // Error state for CSV Upload or Form submissions
  const [errorText, setErrorText] = useState("");
  const [successText, setSuccessText] = useState("");

  // Static product suggest options derived from active catalog list
  const catalogSuggestions = useMemo(() => {
    const list = new Set<string>();
    transactions.forEach(t => list.add(t.product));
    return Array.from(list);
  }, [transactions]);

  // Unique payment methods list
  const paymentMethodsList = useMemo(() => {
    const list = new Set<string>();
    transactions.forEach(t => list.add(t.paymentMethod));
    return Array.from(list);
  }, [transactions]);

  // Generate a random Order Number suggestion
  const generateSuggestedOrderNum = () => {
    const maxNo = transactions.reduce((max, t) => {
      const parsed = parseInt(t.orderNumber.replace(/[^\d]/g, ""));
      return isNaN(parsed) ? max : Math.max(max, parsed);
    }, 1000);
    return `TT-${maxNo + 1}`;
  };

  const handleOpenAddForm = () => {
    setNewOrderNum(generateSuggestedOrderNum());
    setNewProduct(catalogSuggestions[0] || "Custom Fit Jeans");
    setNewPrice("88.00");
    setNewDate(new Date().toISOString().split("T")[0]);
    setNewPaymentMethod("Credit Card");
    setShowAddForm(true);
    setErrorText("");
    setSuccessText("");
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrderNum || !newProduct || !newPrice || !newDate || !newPaymentMethod) {
      setErrorText("Please fill out all fields before submitting");
      return;
    }

    const priceNum = parseFloat(newPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      setErrorText("Please enter a valid price greater than 0");
      return;
    }

    onAddTransaction({
      orderNumber: newOrderNum,
      product: newProduct,
      price: priceNum,
      date: newDate,
      paymentMethod: newPaymentMethod
    });

    setSuccessText(`Successfully added order ${newOrderNum}!`);
    setTimeout(() => {
      setSuccessText("");
      setShowAddForm(false);
    }, 1500);
  };

  // Drag and Drop File Handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setErrorText("");
    const file = e.dataTransfer.files[0];
    if (file) {
      processCSVFile(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorText("");
    const file = e.target.files?.[0];
    if (file) {
      processCSVFile(file);
    }
  };

  const processCSVFile = (file: File) => {
    if (!file.name.endsWith(".csv")) {
      setErrorText("Invalid file type. Please upload a structured .csv sheet");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        try {
          const parsed = parseCSVString(text);
          if (parsed.length === 0) {
            setErrorText("CSV contains no valid sales transactions or column format mismatches");
            return;
          }
          onSetTransactions(parsed);
          setSuccessText(`Loaded ${parsed.length} custom transactions successfully!`);
          setTimeout(() => setSuccessText(""), 3000);
        } catch (err) {
          setErrorText("Could not process CSV. Please assure headers exist");
        }
      }
    };
    reader.readAsText(file);
  };

  // CSV Export Trigger
  const handleCSVExport = () => {
    const csvContent = exportToCSVString(filteredTransactions);
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `filtered_sales_data_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter application
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      // search match
      const sLower = searchTerm.toLowerCase();
      const matchSearch = searchTerm === "" || 
        t.product.toLowerCase().includes(sLower) || 
        t.orderNumber.toLowerCase().includes(sLower);
      
      // payment match
      const matchPM = selectedMethod === "" || t.paymentMethod === selectedMethod;

      // product match
      const matchProd = selectedProduct === "" || t.product === selectedProduct;

      // Price match
      const numMin = minPrice !== "" ? parseFloat(minPrice) : null;
      const numMax = maxPrice !== "" ? parseFloat(maxPrice) : null;
      const matchPrice = (numMin === null || t.price >= numMin) && (numMax === null || t.price <= numMax);

      // Date match
      const dStart = startDate !== "" ? new Date(startDate).getTime() : null;
      const dEnd = endDate !== "" ? new Date(endDate).getTime() : null;
      const itemTime = new Date(t.date).getTime();
      const matchDate = (dStart === null || itemTime >= dStart) && (dEnd === null || itemTime <= dEnd);

      return matchSearch && matchPM && matchProd && matchPrice && matchDate;
    });
  }, [transactions, searchTerm, selectedMethod, selectedProduct, minPrice, maxPrice, startDate, endDate]);

  // Sort application
  const sortedTransactions = useMemo(() => {
    const items = [...filteredTransactions];
    items.sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];

      if (typeof aVal === "string") {
        aVal = (aVal as string).toLowerCase();
        bVal = (bVal as string).toLowerCase();
      }

      if (aVal < bVal) return sortDirection === "asc" ? -1 : 1;
      if (aVal > bVal) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
    return items;
  }, [filteredTransactions, sortField, sortDirection]);

  // Paginated application
  const paginatedTransactions = useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return sortedTransactions.slice(startIndex, startIndex + pageSize);
  }, [sortedTransactions, currentPage, pageSize]);

  // Max Pages count
  const totalPages = Math.ceil(sortedTransactions.length / pageSize) || 1;

  const handleSort = (field: keyof Transaction) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
    setCurrentPage(1);
  };

  const clearAllFilters = () => {
    setSearchTerm("");
    setSelectedMethod("");
    setSelectedProduct("");
    setMinPrice("");
    setMaxPrice("");
    setStartDate("");
    setEndDate("");
    setCurrentPage(1);
  };

  return (
    <div className="space-y-4">
      
      {/* Messages Alerts */}
      {errorText && (
        <div id="error-message" className="bg-rose-50 border border-rose-200 text-rose-700 text-xs px-3 py-2 rounded flex items-center gap-2 animate-pulse">
          <X className="w-3.5 h-3.5 shrink-0" />
          <p className="font-semibold">{errorText}</p>
        </div>
      )}
      {successText && (
        <div id="success-message" className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs px-3 py-2 rounded flex items-center gap-2">
          <Check className="w-3.5 h-3.5 shrink-0 animate-bounce" />
          <p className="font-semibold">{successText}</p>
        </div>
      )}

      {/* Control panel: Form Drawer & Import File Drag Block */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* CSV Drag and Drop Zone (1 Col) */}
        <div 
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className="bg-white rounded-lg border-2 border-dashed border-slate-200 hover:border-indigo-400 p-4 shadow-sm text-center transition-all flex flex-col justify-between"
        >
          <div>
            <div className="mx-auto w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 mb-2">
              <FileSpreadsheet className="w-5 h-5 animate-pulse" />
            </div>
            <h4 className="font-bold text-slate-800 text-sm">Upload Custom CSV Sales</h4>
            <p className="text-[11px] text-slate-400 mt-0.5 max-w-xs mx-auto">
              Drag & drop any transaction CSV file here, or click to upload catalog sheets dynamically
            </p>
          </div>

          <div className="mt-3">
            <label className="bg-indigo-600 cursor-pointer hover:bg-indigo-700 text-white font-bold text-xs px-3 py-2 rounded transition-all inline-block">
              Choose CSV File
              <input 
                type="file" 
                accept=".csv" 
                onChange={handleFileInput} 
                className="hidden" 
              />
            </label>
            <button 
              onClick={onRestoreDefaults}
              className="mt-2.5 block mx-auto text-xs font-bold text-indigo-600 hover:text-indigo-800 underline transition-all flex items-center justify-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              Reset Original Dataset
            </button>
          </div>
        </div>

        {/* Filter Desk Panel (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 p-4 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 justify-between">
              <span className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Filter className="w-3.5 h-3.5 text-indigo-600" />
                Active Dataset Filters
              </span>
              <button 
                onClick={clearAllFilters}
                className="text-[11px] font-bold text-slate-400 hover:text-slate-600 transition-all"
              >
                Clear all filters
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Product Search */}
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search order #, product..."
                  value={searchTerm}
                  onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                  className="pl-8.5 w-full bg-slate-50 border border-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-400 rounded py-1.5 text-xs text-slate-800 font-medium"
                />
              </div>

              {/* Product suggestion Dropdown */}
              <select
                value={selectedProduct}
                onChange={(e) => { setSelectedProduct(e.target.value); setCurrentPage(1); }}
                className="w-full bg-slate-50 border border-slate-200 focus:outline-none focus:border-indigo-400 rounded py-1.5 px-2 text-xs text-slate-750 font-medium"
              >
                <option value="">All Catalog Products</option>
                {catalogSuggestions.map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>

              {/* Payment Suggestion */}
              <select
                value={selectedMethod}
                onChange={(e) => { setSelectedMethod(e.target.value); setCurrentPage(1); }}
                className="w-full bg-slate-50 border border-slate-200 focus:outline-none focus:border-indigo-400 rounded py-1.5 px-2 text-xs text-slate-700 font-medium"
              >
                <option value="">All Payment Methods</option>
                {paymentMethodsList.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>

              {/* Slide price bound */}
              <div className="relative">
                <span className="absolute left-2.5 top-2.5 text-[9px] uppercase font-bold text-slate-450">Min $</span>
                <input 
                  type="number" 
                  placeholder="Min Price"
                  value={minPrice}
                  onChange={(e) => { setMinPrice(e.target.value); setCurrentPage(1); }}
                  className="pl-12 w-full bg-slate-50 border border-slate-200 focus:outline-none focus:border-indigo-400 rounded py-1.5 text-xs text-slate-800 font-mono"
                />
              </div>

              <div className="relative">
                <span className="absolute left-2.5 top-2.5 text-[9px] uppercase font-bold text-slate-450">Max $</span>
                <input 
                  type="number" 
                  placeholder="Max Price"
                  value={maxPrice}
                  onChange={(e) => { setMaxPrice(e.target.value); setCurrentPage(1); }}
                  className="pl-12 w-full bg-slate-50 border border-slate-200 focus:outline-none focus:border-indigo-400 rounded py-1.5 text-xs text-slate-800 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <input 
                  type="date" 
                  value={startDate}
                  onChange={(e) => { setStartDate(e.target.value); setCurrentPage(1); }}
                  className="w-full bg-slate-50 border border-slate-200 focus:outline-none focus:border-indigo-400 rounded py-1.5 px-2 text-[10px] text-slate-700 font-mono"
                />
                <input 
                  type="date" 
                  value={endDate}
                  onChange={(e) => { setEndDate(e.target.value); setCurrentPage(1); }}
                  className="w-full bg-slate-50 border border-slate-200 focus:outline-none focus:border-indigo-400 rounded py-1.5 px-2 text-[10px] text-slate-700 font-mono"
                />
              </div>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">
              Matched: <span className="font-bold text-indigo-700">{filteredTransactions.length}</span> / {transactions.length} rows
            </span>
            <button 
              onClick={handleCSVExport}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-all flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              Download Clean CSV
            </button>
          </div>
        </div>

      </div>

      {/* Main ledger database view and form input dropdown on request */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
        
        {/* Table header bar */}
        <div className="flex items-center justify-between flex-wrap gap-4 mb-3">
          <div>
            <h3 className="font-bold text-sm text-slate-800">Operational Order Ledger</h3>
            <p className="text-[11px] text-slate-400">Filter, search, audit, or completely erase specific row entries</p>
          </div>
          
          <button 
            onClick={handleOpenAddForm}
            className="bg-slate-900 border border-slate-900 text-white hover:bg-slate-800 font-medium text-xs px-3 py-1.5 rounded transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Add New Order
          </button>
        </div>

        {/* Inline form card */}
        {showAddForm && (
          <div className="bg-slate-50 border border-slate-100 p-5 rounded-xl mb-6 relative animate-in fade-in zoom-in duration-200">
            <button 
              onClick={() => setShowAddForm(false)}
              className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
            <h4 className="font-bold text-xs uppercase text-indigo-700 tracking-wider mb-3 block">Insert Custom Order Item</h4>
            
            <form onSubmit={handleAddSubmit} className="grid grid-cols-1 sm:grid-cols-5 gap-3.5 items-end">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Order #</label>
                <input 
                  type="text" 
                  value={newOrderNum}
                  onChange={(e) => setNewOrderNum(e.target.value)}
                  placeholder="e.g. TT-1100"
                  className="w-full bg-white border border-slate-200/80 rounded-lg p-2 text-xs text-slate-800 font-mono focus:outline-indigo-400"
                />
              </div>
              
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Product</label>
                <select
                  value={newProduct}
                  onChange={(e) => setNewProduct(e.target.value)}
                  className="w-full bg-white border border-slate-200/80 rounded-lg p-2 text-xs text-slate-800 focus:outline-indigo-400"
                >
                  {catalogSuggestions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                  <option value="Classic Work Trousers">Classic Work Trousers (New)</option>
                  <option value="Premium Leather Vest">Premium Leather Vest (New)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Price ($)</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={newPrice}
                  onChange={(e) => setNewPrice(e.target.value)}
                  placeholder="85.00"
                  className="w-full bg-white border border-slate-200/80 rounded-lg p-2 text-xs text-slate-800 font-mono focus:outline-indigo-400"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Checkout Date</label>
                <input 
                  type="date" 
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full bg-white border border-slate-200/80 rounded-lg p-2 text-xs text-slate-800 font-mono focus:outline-indigo-400"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Gateway Mode</label>
                <select
                  value={newPaymentMethod}
                  onChange={(e) => setNewPaymentMethod(e.target.value)}
                  className="w-full bg-white border border-slate-200/80 rounded-lg p-2 text-xs text-slate-800 focus:outline-indigo-400"
                >
                  <option value="Credit Card">Credit Card</option>
                  <option value="Debit Card">Debit Card</option>
                  <option value="eWallet">eWallet</option>
                  <option value="Cash">Cash</option>
                </select>
              </div>

              <div className="sm:col-span-5 flex justify-end gap-2 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-500 rounded-lg text-xs font-semibold hover:bg-slate-100 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 transition-all"
                >
                  <Save className="w-3.5 h-3.5" />
                  Save Order
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Entries Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse select-none">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 text-[10px] font-semibold uppercase tracking-wider">
                <th className="py-2.5 px-3 cursor-pointer hover:bg-slate-50 rounded transition-all" onClick={() => handleSort("orderNumber")}>
                  Order # {sortField === "orderNumber" && (sortDirection === "asc" ? "▲" : "▼")}
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:bg-slate-50 rounded transition-all" onClick={() => handleSort("product")}>
                  Product Name {sortField === "product" && (sortDirection === "asc" ? "▲" : "▼")}
                </th>
                <th className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-50 rounded transition-all" onClick={() => handleSort("price")}>
                  Price {sortField === "price" && (sortDirection === "asc" ? "▲" : "▼")}
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:bg-slate-50 rounded transition-all" onClick={() => handleSort("date")}>
                  Checkout Date {sortField === "date" && (sortDirection === "asc" ? "▲" : "▼")}
                </th>
                <th className="py-2.5 px-3 cursor-pointer hover:bg-slate-50 rounded transition-all" onClick={() => handleSort("paymentMethod")}>
                  Method {sortField === "paymentMethod" && (sortDirection === "asc" ? "▲" : "▼")}
                </th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[13px]">
              {paginatedTransactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-400 text-xs">
                    No transactions matching filtration constraints. Clear constraints or upload data.
                  </td>
                </tr>
              ) : (
                paginatedTransactions.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 transition-all">
                    <td className="py-1.5 px-3 font-mono font-bold text-slate-800">{item.orderNumber}</td>
                    <td className="py-1.5 px-3 font-semibold text-slate-700">{item.product}</td>
                    <td className="py-1.5 px-3 text-right font-bold text-slate-900 font-mono">${item.price.toFixed(2)}</td>
                    <td className="py-1.5 px-3 text-slate-500 font-mono">{item.date}</td>
                    <td className="py-1.5 px-3">
                      <span className="inline-flex items-center text-[10px] font-semibold px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                        {item.paymentMethod}
                      </span>
                    </td>
                    <td className="py-1.5 px-3 text-center">
                      <button 
                        onClick={() => onDeleteTransaction(item.id)}
                        className="text-slate-400 hover:text-red-500 p-1 hover:bg-red-50 rounded transition-all inline-block"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Pagination */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-medium">
          <div className="flex items-center gap-2 text-[11px] text-slate-500">
            <span>Rows:</span>
            <select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
              className="bg-slate-50 border border-slate-200 rounded px-1 py-0.5 outline-none font-bold text-slate-700"
            >
              {[10, 15, 25, 50].map(sz => (
                <option key={sz} value={sz}>{sz}</option>
              ))}
            </select>
            <span className="ml-2">
              Matched: <span className="font-bold text-slate-800">{sortedTransactions.length}</span> (Page {currentPage} of {totalPages})
            </span>
          </div>

          <div className="flex items-center gap-1 text-[11px]">
            <button 
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              className="p-1 px-2 border border-slate-200 hover:bg-slate-100 rounded text-slate-600 disabled:opacity-40 disabled:hover:bg-transparent"
            >
              <ChevronLeft className="w-3.5 h-3.5 inline mr-0.5" />
              Previous
            </button>
            <button 
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              className="p-1 px-2 border border-slate-200 hover:bg-slate-100 rounded text-slate-600 disabled:opacity-40 disabled:hover:bg-transparent"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5 inline ml-0.5" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
