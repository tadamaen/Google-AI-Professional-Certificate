import React, { useState, useMemo } from "react";
import { Transaction } from "../data";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, PieChart, Pie, Legend, LineChart, Line
} from "recharts";
import { TrendingUp, BarChart3, PieChart as PieIcon, Award, DollarSign, ListOrdered, Calendar } from "lucide-react";
import { motion } from "motion/react";

interface OverviewTabProps {
  transactions: Transaction[];
  onProductClick?: (productName: string) => void;
  onPaymentMethodClick?: (method: string) => void;
}

export default function OverviewTab({ transactions, onProductClick, onPaymentMethodClick }: OverviewTabProps) {
  const [salesGrouping, setSalesGrouping] = useState<"daily" | "weekly">("daily");
  const [chartType, setChartType] = useState<"area" | "line" | "bar">("area");

  // sales over time data preparation
  const salesOverTimeData = useMemo(() => {
    // Group transactions by date
    const dateMap: Record<string, { date: string; amount: number; count: number }> = {};
    
    // Sort transactions by date first
    const sorted = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    sorted.forEach((t) => {
      if (!dateMap[t.date]) {
        dateMap[t.date] = { date: t.date, amount: 0, count: 0 };
      }
      dateMap[t.date].amount += t.price;
      dateMap[t.date].count += 1;
    });

    const dailyData = Object.values(dateMap);

    if (salesGrouping === "daily") {
      return dailyData;
    }

    // Grouping weekly starting from first transaction
    const weeklyData: { week: string; amount: number; count: number }[] = [];
    if (dailyData.length === 0) return [];
    
    let currentWeekSum = 0;
    let currentWeekCount = 0;
    let weekStartDate = dailyData[0].date;
    let countDays = 0;

    dailyData.forEach((d, idx) => {
      currentWeekSum += d.amount;
      currentWeekCount += d.count;
      countDays++;

      if (countDays === 7 || idx === dailyData.length - 1) {
        weeklyData.push({
          week: `${weekStartDate} (#W${weeklyData.length + 1})`,
          amount: parseFloat(currentWeekSum.toFixed(2)),
          count: currentWeekCount
        });
        currentWeekSum = 0;
        currentWeekCount = 0;
        countDays = 0;
        if (idx < dailyData.length - 1) {
          weekStartDate = dailyData[idx + 1].date;
        }
      }
    });

    return weeklyData;
  }, [transactions, salesGrouping]);

  // Product popularity calculation
  const productChartData = useMemo(() => {
    const map: Record<string, { product: string; revenue: number; units: number }> = {};
    transactions.forEach(t => {
      if (!map[t.product]) {
        map[t.product] = { product: t.product, revenue: 0, units: 0 };
      }
      map[t.product].revenue += t.price;
      map[t.product].units += 1;
    });
    return Object.values(map)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 7); // Top 7 products
  }, [transactions]);

  // Payment methods calculation
  const paymentChartData = useMemo(() => {
    const map: Record<string, { name: string; value: number; revenue: number }> = {};
    transactions.forEach(t => {
      if (!map[t.paymentMethod]) {
        map[t.paymentMethod] = { name: t.paymentMethod, value: 0, revenue: 0 };
      }
      map[t.paymentMethod].value += 1;
      map[t.paymentMethod].revenue += t.price;
    });
    return Object.values(map);
  }, [transactions]);

  // Insights / Fast Summary Metrics
  const insights = useMemo(() => {
    if (transactions.length === 0) return { peakDate: "N/A", topProduct: "N/A", topPayMethod: "N/A", maxOrderVal: 0 };
    
    // Find peak billing date
    const dateSums: Record<string, number> = {};
    let maxDateSum = 0;
    let peakDate = "";
    transactions.forEach(t => {
      dateSums[t.date] = (dateSums[t.date] || 0) + t.price;
      if (dateSums[t.date] > maxDateSum) {
        maxDateSum = dateSums[t.date];
        peakDate = t.date;
      }
    });

    // Find top selling product by revenue
    const productSums: Record<string, number> = {};
    let maxProductSum = 0;
    let topProduct = "";
    transactions.forEach(t => {
      productSums[t.product] = (productSums[t.product] || 0) + t.price;
      if (productSums[t.product] > maxProductSum) {
        maxProductSum = productSums[t.product];
        topProduct = t.product;
      }
    });

    // Find peak single order amount
    const orderSums: Record<string, number> = {};
    let maxOrderVal = 0;
    transactions.forEach(t => {
      orderSums[t.orderNumber] = (orderSums[t.orderNumber] || 0) + t.price;
      if (orderSums[t.orderNumber] > maxOrderVal) {
        maxOrderVal = orderSums[t.orderNumber];
      }
    });

    // Top payment method by count
    const paymentSums: Record<string, number> = {};
    let maxPayCount = 0;
    let topPayMethod = "";
    transactions.forEach(t => {
      paymentSums[t.paymentMethod] = (paymentSums[t.paymentMethod] || 0) + 1;
      if (paymentSums[t.paymentMethod] > maxPayCount) {
        maxPayCount = paymentSums[t.paymentMethod];
        topPayMethod = t.paymentMethod;
      }
    });

    return {
      peakDate,
      peakDateRevenue: maxDateSum.toFixed(2),
      topProduct,
      topPayMethod,
      maxOrderVal: maxOrderVal.toFixed(2)
    };
  }, [transactions]);

  const COLORS = ["#4338ca", "#06b6d4", "#f59e0b", "#ec4899", "#10b981", "#8b5cf6", "#3b82f6"];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      
      {/* Sales Trend (Primary Big Widget spans 2 cols) */}
      <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 p-4 shadow-sm flex flex-col justify-between">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-50 rounded text-indigo-600 border border-indigo-100/30">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Revenue Stream Analysis</h3>
              <p className="text-[11px] text-slate-400">Total earned sales trajectory and frequency distribution</p>
            </div>
          </div>

          {/* Group Controls */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Daily/Weekly */}
            <div className="bg-slate-100 p-1 rounded-lg flex">
              <button
                onClick={() => setSalesGrouping("daily")}
                className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                  salesGrouping === "daily" ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Daily
              </button>
              <button
                onClick={() => setSalesGrouping("weekly")}
                className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                  salesGrouping === "weekly" ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Weekly
              </button>
            </div>

            {/* Chart Type */}
            <div className="bg-slate-100 p-1 rounded-lg flex">
              <button
                onClick={() => setChartType("area")}
                className={`px-2.5 py-1.5 rounded-md transition-all font-semibold ${
                  chartType === "area" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Area
              </button>
              <button
                onClick={() => setChartType("line")}
                className={`px-2.5 py-1.5 rounded-md transition-all font-semibold ${
                  chartType === "line" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Line
              </button>
              <button
                onClick={() => setChartType("bar")}
                className={`px-2.5 py-1.5 rounded-md transition-all font-semibold ${
                  chartType === "bar" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-800"
                }`}
              >
                Bar
              </button>
            </div>
          </div>
        </div>

        {/* Sales Chart stage container */}
        <div className="h-80 w-full">
          {transactions.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400">
              <p className="text-sm">No data available to show charts</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              {chartType === "area" ? (
                <AreaChart data={salesOverTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4338ca" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#4338ca" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey={salesGrouping === "daily" ? "date" : "week"} 
                    stroke="#94a3b8" 
                    fontSize={10} 
                    tickLine={false}
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis 
                    stroke="#94a3b8" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(val) => `$${val}`}
                  />
                  <Tooltip 
                    contentStyle={{ border: "none", borderRadius: "12px", boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)" }}
                    formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Revenue"]}
                  />
                  <Area type="monotone" dataKey="amount" stroke="#4338ca" strokeWidth={2.5} fillOpacity={1} fill="url(#colorSales)" />
                </AreaChart>
              ) : chartType === "line" ? (
                <LineChart data={salesOverTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey={salesGrouping === "daily" ? "date" : "week"}
                    stroke="#94a3b8" 
                    fontSize={10} 
                    tickLine={false}
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis 
                    stroke="#94a3b8" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(val) => `$${val}`}
                  />
                  <Tooltip 
                    contentStyle={{ border: "none" }}
                    formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Revenue"]}
                  />
                  <Line type="monotone" dataKey="amount" stroke="#4338ca" strokeWidth={3} dot={{ r: 3, fill: "#4338ca", strokeWidth: 1 }} hoverDot={{ r: 6 }} />
                </LineChart>
              ) : (
                <BarChart data={salesOverTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey={salesGrouping === "daily" ? "date" : "week"}
                    stroke="#94a3b8" 
                    fontSize={10} 
                    tickLine={false}
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis 
                    stroke="#94a3b8" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(val) => `$${val}`}
                  />
                  <Tooltip 
                    contentStyle={{ border: "none" }}
                    formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Revenue"]}
                  />
                  <Bar dataKey="amount" fill="#4338ca" radius={[4, 4, 0, 0]} barSize={salesGrouping === "daily" ? 14 : 32} />
                </BarChart>
              )}
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Payment Method Pie Chart (1 Col) */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-amber-50 rounded text-amber-600 border border-amber-100/30">
              <PieIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Payment Modes</h3>
              <p className="text-[11px] text-slate-400">Order split and preferences</p>
            </div>
          </div>
          
          <div className="h-60 w-full relative flex items-center justify-center">
            {transactions.length === 0 ? (
              <div className="text-slate-400 text-sm">No payment data</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={paymentChartData}
                    cx="50%"
                    cy="48%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {paymentChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: any, name: any) => [`${value} orders`, name]} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Custom Legend */}
        <div className="border-t border-slate-50 pt-4 mt-2">
          <div className="grid grid-cols-2 gap-3">
            {paymentChartData.map((data, idx) => (
              <div 
                key={idx} 
                className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 p-1.5 rounded-md transition-all"
                onClick={() => onPaymentMethodClick && onPaymentMethodClick(data.name)}
              >
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></span>
                <span className="text-slate-500 font-medium truncate">{data.name}</span>
                <span className="text-slate-800 font-bold ml-auto font-mono">{data.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Products Horizontal Bar Chart (2 Cols) */}
      <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 p-4 shadow-sm select-none">
        <div className="flex items-center gap-2 mb-4 justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-emerald-50 rounded text-emerald-600 border border-emerald-100/30">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Popular Catalog Performance</h3>
              <p className="text-[11px] text-slate-400">Total units sold and revenue share for top catalogs</p>
            </div>
          </div>
        </div>

        <div className="h-68 w-full">
          {transactions.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-400">No data</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productChartData} layout="vertical" margin={{ top: 0, right: 10, left: 30, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
                <YAxis dataKey="product" type="category" stroke="#64748b" fontSize={10} width={120} tickLine={false} axisLine={false} />
                <Tooltip formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Revenue"]} />
                <Bar dataKey="revenue" fill="#4f46e5" radius={[0, 4, 4, 0]} barSize={16}>
                  {productChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className="cursor-pointer" onClick={() => onProductClick && onProductClick(entry.product)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Business Highlights & Contextual Insights Bento (1 Col) */}
      <div className="bg-gradient-to-br from-indigo-950 to-slate-900 text-white rounded-lg p-4 shadow-sm flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-white/10 rounded text-indigo-300">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold">Data Highlights</h3>
              <p className="text-[11px] text-indigo-200">System generated metrics & indicators</p>
            </div>
          </div>

          <div className="space-y-2.5">
            <div className="bg-white/5 border border-white/10 p-2.5 rounded-md flex items-center gap-2.5">
              <div className="p-1.5 bg-indigo-500/20 text-indigo-300 rounded shrink-0">
                <Calendar className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <span className="text-[9px] uppercase font-bold text-indigo-300 block leading-tight">Peak Revenue Date</span>
                <span className="text-xs font-semibold block truncate text-white">{insights.peakDate}</span>
                <span className="text-[10px] text-indigo-200 block leading-none">${insights.peakDateRevenue} generated</span>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-2.5 rounded-md flex items-center gap-2.5 cursor-pointer hover:bg-white/10 transition-all" onClick={() => onProductClick && onProductClick(insights.topProduct)}>
              <div className="p-1.5 bg-pink-500/20 text-pink-300 rounded shrink-0">
                <Award className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <span className="text-[9px] uppercase font-bold text-pink-300 block leading-tight">Top Revenue Product</span>
                <span className="text-xs font-semibold block truncate text-white">{insights.topProduct}</span>
                <span className="text-[10px] text-pink-200 block leading-none">Catalog star performer</span>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-2.5 rounded-md flex items-center gap-2.5">
              <div className="p-1.5 bg-amber-500/20 text-amber-300 rounded shrink-0">
                <DollarSign className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <span className="text-[9px] uppercase font-bold text-amber-300 block leading-tight">Peak Order Value</span>
                <span className="text-xs font-semibold block text-white font-mono">{insights.maxOrderVal !== "0" ? `$${insights.maxOrderVal}` : "$0.00"}</span>
                <span className="text-[10px] text-amber-200 block leading-none">Single highest basket</span>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-2.5 rounded-md flex items-center gap-2.5">
              <div className="p-1.5 bg-emerald-500/20 text-emerald-300 rounded shrink-0">
                <ListOrdered className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <span className="text-[9px] uppercase font-bold text-emerald-300 block leading-tight">Top Payment Type</span>
                <span className="text-xs font-semibold block text-white">{insights.topPayMethod}</span>
                <span className="text-[10px] text-emerald-200 block leading-none">Most frequent channel</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 border-t border-white/10 pt-3 text-center">
          <p className="text-[9px] text-indigo-300 font-mono">
            COMPUTED: {transactions.length} RECS
          </p>
        </div>
      </div>

    </div>
  );
}
