import React, { useMemo } from "react";
import { Transaction } from "../data";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  Cell, AreaChart, Area
} from "recharts";
import { CreditCard, Wallet, Coins, RefreshCw, BarChart3, TrendingUp, DollarSign } from "lucide-react";

interface PaymentsTabProps {
  transactions: Transaction[];
  initialSelectedMethod?: string;
}

export default function PaymentsTab({ transactions, initialSelectedMethod }: PaymentsTabProps) {
  
  // Aggregate stats per payment method
  const paymentStats = useMemo(() => {
    const map: Record<string, { 
      name: string; 
      revenue: number; 
      count: number; 
      transactionPrices: number[];
    }> = {};

    transactions.forEach(t => {
      if (!map[t.paymentMethod]) {
        map[t.paymentMethod] = { 
          name: t.paymentMethod, 
          revenue: 0, 
          count: 0, 
          transactionPrices: [] 
        };
      }
      const p = map[t.paymentMethod];
      p.revenue += t.price;
      p.count += 1;
      p.transactionPrices.push(t.price);
    });

    return Object.values(map).map(p => {
      const sortedPrices = [...p.transactionPrices].sort((a, b) => a - b);
      const median = sortedPrices.length > 0 
        ? sortedPrices[Math.floor(sortedPrices.length / 2)] 
        : 0;

      return {
        name: p.name,
        revenue: p.revenue,
        count: p.count,
        aov: p.count > 0 ? (p.revenue / p.count) : 0,
        median,
        percentage: transactions.reduce((sum, t) => sum + t.price, 0) > 0 
          ? (p.revenue / transactions.reduce((sum, t) => sum + t.price, 0) * 100)
          : 0
      };
    }).sort((a, b) => b.revenue - a.revenue);
  }, [transactions]);

  // Payment method popularity trend over time (for the line chart)
  const paymentTimelineData = useMemo(() => {
    // Collect all unique dates sorted
    const dateSet = new Set<string>();
    transactions.forEach(t => dateSet.add(t.date));
    const sortedDates = Array.from(dateSet).sort();

    // Sum transactions per payment method per date
    return sortedDates.map(date => {
      const point: Record<string, any> = { date };
      const methods = ["Credit Card", "eWallet", "Cash", "Debit Card"];
      
      methods.forEach(m => {
        point[m] = transactions
          .filter(t => t.date === date && t.paymentMethod === m)
          .reduce((sum, t) => sum + t.price, 0);
      });
      return point;
    });
  }, [transactions]);

  const COLORS = ["#4338ca", "#06b6d4", "#f59e0b", "#ec4899"];

  const getMethodIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes("credit") || lower.includes("card") || lower.includes("debit")) {
      return <CreditCard className="w-5 h-5" />;
    } else if (lower.includes("wallet")) {
      return <Wallet className="w-5 h-5" />;
    } else {
      return <Coins className="w-5 h-5" />;
    }
  };

  const getMethodColorClass = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes("credit") || lower.includes("card")) {
      return "text-indigo-600 bg-indigo-50 border-indigo-100";
    } else if (lower.includes("wallet")) {
      return "text-cyan-600 bg-cyan-50 border-cyan-100";
    } else if (lower.includes("debit")) {
      return "text-pink-600 bg-pink-50 border-pink-100";
    } else {
      return "text-amber-600 bg-amber-50 border-amber-100";
    }
  };

  return (
    <div className="space-y-4">
      
      {/* Payment overview grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {paymentStats.map((item, idx) => (
          <div 
            key={item.name} 
            className={`bg-white rounded-lg p-4 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${
              initialSelectedMethod === item.name ? "ring-2 ring-indigo-500 bg-indigo-50/5" : ""
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-tight block mb-0.5">
                  {item.name}
                </span>
                <span className="text-lg font-mono font-bold text-slate-800 tracking-tight block">
                  ${item.revenue.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-[10px] text-slate-450 mt-0.5 block">
                  {item.percentage.toFixed(1)}% revenue share
                </span>
              </div>
              <div className={`p-1.5 rounded-md border shrink-0 ${getMethodColorClass(item.name)}`}>
                {getMethodIcon(item.name)}
              </div>
            </div>

            <div className="mt-3 border-t border-slate-100 pt-2.5 flex items-center justify-between text-[11px] text-slate-500">
              <span className="font-medium">{item.count} checkouts</span>
              <span className="font-bold text-slate-700 font-mono">AOV: ${item.aov.toFixed(2)}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Payment methods stack area timeline or cumulative comparison details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Cumulative Timeline */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-indigo-50 rounded text-indigo-600 border border-indigo-100/30">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Checkout Trends Tracking</h3>
              <p className="text-[11px] text-slate-400">Fluctuations in daily checkout volumes by specific channels</p>
            </div>
          </div>

          <div className="h-80 w-full">
            {transactions.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-400">No data</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={paymentTimelineData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="payCredit" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#4338ca" stopOpacity={0.15}/><stop offset="95%" stopColor="#4338ca" stopOpacity={0}/></linearGradient>
                    <linearGradient id="payWallet" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#06b6d4" stopOpacity={0.15}/><stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/></linearGradient>
                    <linearGradient id="payCash" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#f59e0b" stopOpacity={0.15}/><stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/></linearGradient>
                    <linearGradient id="payDebit" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#ec4899" stopOpacity={0.15}/><stop offset="95%" stopColor="#ec4899" stopOpacity={0}/></linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} dy={8} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
                  <Tooltip formatter={(value: any, name: any) => [`$${parseFloat(value).toFixed(2)}`, name]} />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: "11px", paddingTop: "15px" }} />
                  <Area type="monotone" stackId="1" dataKey="Credit Card" stroke="#4338ca" fillOpacity={1} fill="url(#payCredit)" strokeWidth={2} />
                  <Area type="monotone" stackId="1" dataKey="eWallet" stroke="#06b6d4" fillOpacity={1} fill="url(#payWallet)" strokeWidth={2} />
                  <Area type="monotone" stackId="1" dataKey="Cash" stroke="#f59e0b" fillOpacity={1} fill="url(#payCash)" strokeWidth={2} />
                  <Area type="monotone" stackId="1" dataKey="Debit Card" stroke="#ec4899" fillOpacity={1} fill="url(#payDebit)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Average cart size by payment type */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-pink-50 rounded text-pink-600 border border-pink-100/30">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Gateway Worth (AOV)</h3>
              <p className="text-[11px] text-slate-400">Mean cart value processed by each gateway</p>
            </div>
          </div>

          <div className="h-72 w-full flex items-center justify-center">
            {transactions.length === 0 ? (
              <div className="text-slate-400 text-sm">No data</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={paymentStats} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
                  <Tooltip formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Average Cart Value"]} />
                  <Bar dataKey="aov" radius={[4, 4, 0, 0]} barSize={34}>
                    {paymentStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-50 text-center">
            <span className="text-[11px] text-slate-400 font-medium">
              Higher Cart Value indicates consumers buy premium bulk sets with digital credit gateways.
            </span>
          </div>
        </div>

      </div>

    </div>
  );
}
