import React, { useState, useMemo } from "react";
import { Transaction } from "../data";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, Cell
} from "recharts";
import { ShoppingBag, ChevronRight, BarChart3, Star, Percent, Tags, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface ProductsTabProps {
  transactions: Transaction[];
  initialSelectedProduct?: string;
}

export default function ProductsTab({ transactions, initialSelectedProduct }: ProductsTabProps) {
  // Extract all unique product names
  const productsList = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach(t => set.add(t.product));
    return Array.from(set).sort();
  }, [transactions]);

  // Selected products for comparison chart
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>(
    initialSelectedProduct ? [initialSelectedProduct] : productsList.slice(0, 3)
  );

  // Update selected comparison product if the dashboard instructs us to
  React.useEffect(() => {
    if (initialSelectedProduct && !selectedForCompare.includes(initialSelectedProduct)) {
      setSelectedForCompare((prev) => [...new Set([initialSelectedProduct, ...prev])]);
    }
  }, [initialSelectedProduct]);

  // Aggregate stats per product
  const productStats = useMemo(() => {
    const statsMap: Record<string, { 
      product: string; 
      revenue: number; 
      units: number; 
      payments: Record<string, number>;
      dates: Record<string, number>;
    }> = {};

    transactions.forEach(t => {
      if (!statsMap[t.product]) {
        statsMap[t.product] = { 
          product: t.product, 
          revenue: 0, 
          units: 0, 
          payments: {}, 
          dates: {} 
        };
      }
      const s = statsMap[t.product];
      s.revenue += t.price;
      s.units += 1;
      s.payments[t.paymentMethod] = (s.payments[t.paymentMethod] || 0) + 1;
      s.dates[t.date] = (s.dates[t.date] || 0) + t.price;
    });

    return Object.values(statsMap).map(p => {
      // Find top payment method
      let topPayment = "None";
      let topCount = 0;
      Object.entries(p.payments).forEach(([pm, count]) => {
        if (count > topCount) {
          topCount = count;
          topPayment = pm;
        }
      });

      return {
        product: p.product,
        revenue: p.revenue,
        units: p.units,
        averagePrice: p.units > 0 ? (p.revenue / p.units) : 0,
        topPayment,
        dateSales: p.dates
      };
    }).sort((a, b) => b.revenue - a.revenue);
  }, [transactions]);

  // Chart data for comparing products over time
  const comparisonChartData = useMemo(() => {
    // Collect all dates
    const dateSet = new Set<string>();
    transactions.forEach(t => dateSet.add(t.date));
    const sortedDates = Array.from(dateSet).sort();

    // Map each date to revenue of selected compare items
    return sortedDates.map(date => {
      const point: Record<string, any> = { date };
      selectedForCompare.forEach(prod => {
        // Find sum for this product on this date
        const matchSum = transactions
          .filter(t => t.product === prod && t.date === date)
          .reduce((sum, t) => sum + t.price, 0);
        point[prod] = matchSum > 0 ? matchSum : 0;
      });
      return point;
    });
  }, [transactions, selectedForCompare]);

  const toggleCompare = (product: string) => {
    if (selectedForCompare.includes(product)) {
      if (selectedForCompare.length > 1) {
        setSelectedForCompare(selectedForCompare.filter(p => p !== product));
      }
    } else {
      setSelectedForCompare([...selectedForCompare, product]);
    }
  };

  const COLORS = ["#4338ca", "#06b6d4", "#f59e0b", "#ec4899", "#10b981", "#8b5cf6", "#3b82f6", "#ef4444"];

  return (
    <div className="space-y-4">
      
      {/* Product Comparison Engine */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 bg-indigo-50 rounded text-indigo-600 border border-indigo-100/30">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Dynamic Multi-Product Matchup</h3>
              <p className="text-[11px] text-slate-400">Select catalog items to map and contrast custom timelines side-by-side</p>
            </div>
          </div>
          
          {/* Select checkboxes */}
          <div className="flex flex-wrap gap-2 mt-4">
            {productsList.map((prod, idx) => {
              const isChecked = selectedForCompare.includes(prod);
              const colorIdx = idx % COLORS.length;
              return (
                <button
                  key={prod}
                  onClick={() => toggleCompare(prod)}
                  className={`text-xs px-3 py-2 rounded-lg flex items-center gap-2 font-medium border-2 transition-all ${
                    isChecked
                      ? "bg-slate-900 border-slate-900 text-white"
                      : "bg-slate-50 border-slate-100 hover:border-slate-200 text-slate-600"
                  }`}
                >
                  <span 
                    className="w-2.5 h-2.5 rounded-full block shrink-0" 
                    style={{ backgroundColor: isChecked ? COLORS[colorIdx] : "#94a3b8" }}
                  />
                  <span>{prod}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Comparison Timeline Chart */}
        <div className="h-80 w-full mt-4">
          {selectedForCompare.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-400">
              Please click on any product tag above to initialize comparison
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={comparisonChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} dy={8} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
                <Tooltip formatter={(value: any, name: any) => [`$${parseFloat(value).toFixed(2)}`, name]} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: "11px", paddingTop: "15px" }} />
                {selectedForCompare.map((prod, idx) => (
                  <Line
                    key={prod}
                    type="monotone"
                    dataKey={prod}
                    stroke={COLORS[idx % COLORS.length]}
                    strokeWidth={2.5}
                    dot={{ r: 2, strokeWidth: 1 }}
                    activeDot={{ r: 5 }}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Product Catalog Stats Ledger */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between flex-wrap gap-4 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-pink-50 rounded text-pink-600 border border-pink-100/30">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">In-Depth Catalog Ledger</h3>
              <p className="text-[11px] text-slate-400">Detailed performance audit tracking total revenues, unit velocities & payment types</p>
            </div>
          </div>
        </div>

        {/* Stats Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 text-[10px] font-semibold uppercase tracking-wider">
                <th className="py-2.5 px-3">Item Name</th>
                <th className="py-2.5 px-3 text-right">Revenue Share</th>
                <th className="py-2.5 px-3 text-right">Units Sold</th>
                <th className="py-2.5 px-3 text-right">Avg Unit Pricing</th>
                <th className="py-2.5 px-3">Dominant Gateway</th>
                <th className="py-2.5 px-3 text-center">Interactive Compare</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[13px]">
              {productStats.map((item, index) => {
                const isSelected = selectedForCompare.includes(item.product);
                const colorHex = COLORS[productsList.indexOf(item.product) % COLORS.length];

                return (
                  <tr 
                    key={index} 
                    className={`hover:bg-slate-50/70 transition-all ${isSelected ? "bg-indigo-50/10" : ""}`}
                  >
                    {/* Name */}
                    <td className="py-2 px-3 font-semibold text-slate-800 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: colorHex }} />
                      {item.product}
                    </td>
                    
                    {/* Revenue */}
                    <td className="py-2 px-3 text-right font-bold text-indigo-950 font-mono">
                      ${item.revenue.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    
                    {/* Units */}
                    <td className="py-2 px-3 text-right font-medium text-slate-600 font-mono">
                      {item.units}
                    </td>
                    
                    {/* Avg Price */}
                    <td className="py-2 px-3 text-right text-slate-500 font-mono">
                      ${item.averagePrice.toFixed(2)}
                    </td>
                    
                    {/* Top Payment */}
                    <td className="py-2 px-3">
                      <span className="inline-flex items-center text-[10px] font-semibold px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                        {item.topPayment}
                      </span>
                    </td>
                    
                    {/* MultiCompare Button */}
                    <td className="py-2 px-3 text-center">
                      <button 
                        onClick={() => toggleCompare(item.product)}
                        className={`text-[11px] font-bold px-2 py-0.5 rounded transition-all ${
                          isSelected 
                            ? "bg-indigo-600 text-white shadow-sm"
                            : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                        }`}
                      >
                        {isSelected ? "Comparing" : "Add compare"}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
