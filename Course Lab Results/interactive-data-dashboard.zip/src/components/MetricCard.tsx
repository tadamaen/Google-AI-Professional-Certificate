import React from "react";
import { LucideIcon } from "lucide-react";
import { motion } from "motion/react";

interface MetricCardProps {
  id: string;
  title: string;
  value: string | number;
  icon: LucideIcon;
  description: string;
  trend?: string;
  trendType?: "up" | "down" | "neutral";
  colorClass?: string;
  cardClassName?: string;
}

export default function MetricCard({
  id,
  title,
  value,
  icon: Icon,
  description,
  trend,
  trendType = "neutral",
  colorClass = "text-indigo-600 bg-indigo-50",
  cardClassName = ""
}: MetricCardProps) {
  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      whileHover={{ y: -2 }}
      className={`bg-white rounded-lg p-4 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${cardClassName}`}
    >
      <div className="flex items-start justify-between">
        <div>
          <span className="text-slate-400 text-[11px] font-semibold uppercase tracking-tight block mb-1">
            {title}
          </span>
          <span className="text-2xl font-mono font-bold text-slate-800 tracking-tight">
            {value}
          </span>
        </div>
        <div className={`p-2 rounded-md ${colorClass} shrink-0`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      
      <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2.5">
        <span className="text-[11px] text-slate-400 truncate max-w-[130px]">{description}</span>
        {trend && (
          <span
            className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
              trendType === "up"
                ? "bg-emerald-50 border border-emerald-100 text-emerald-600"
                : trendType === "down"
                ? "bg-rose-50 border border-rose-100 text-rose-600"
                : "bg-slate-50 border border-slate-100 text-slate-600"
            }`}
          >
            {trend}
          </span>
        )}
      </div>
    </motion.div>
  );
}
