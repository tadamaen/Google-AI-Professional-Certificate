import React, { useMemo } from "react";
import { Transaction } from "../data";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell, LineChart, Line, Legend
} from "recharts";
import { Calendar, Clock, BarChart3, TrendingUp, Info } from "lucide-react";

interface TimingTabProps {
  transactions: Transaction[];
}

export default function TimingTab({ transactions }: TimingTabProps) {
  
  // Day of the week calculations
  const dayOfWeekStats = useMemo(() => {
    const daysName = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ];

    // Initialize counts
    const dArray = daysName.map((name, index) => ({
      index,
      day: name,
      revenue: 0,
      count: 0
    }));

    transactions.forEach(t => {
      // Parse date
      const dateObj = new Date(t.date);
      const dayIndex = dateObj.getDay(); // 0 is Sunday, 6 is Saturday
      if (dayIndex >= 0 && dayIndex <= 6) {
        dArray[dayIndex].revenue += t.price;
        dArray[dayIndex].count += 1;
      }
    });

    return dArray.map(item => ({
      ...item,
      aov: item.count > 0 ? (item.revenue / item.count) : 0
    }));
  }, [transactions]);

  // Cohort or Month-over-Month calculation
  const monthlyStats = useMemo(() => {
    const map: Record<string, { month: string; revenue: number; count: number }> = {};
    
    // Sort transactions
    const sorted = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    sorted.forEach(t => {
      const dateObj = new Date(t.date);
      // Format to Year-Month (e.g. 2025-08)
      const monthStr = dateObj.toLocaleString("en-US", { month: "short", year: "numeric" });
      if (!map[monthStr]) {
        map[monthStr] = { month: monthStr, revenue: 0, count: 0 };
      }
      map[monthStr].revenue += t.price;
      map[monthStr].count += 1;
    });

    return Object.values(map);
  }, [transactions]);

  const COLORS = ["#4338ca", "#3b82f6", "#06b6d4", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6"];

  return (
    <div className="space-y-4">
      
      {/* Day of Week Bento Banner explanation */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex gap-3">
          <div className="p-1.5 bg-indigo-50 border border-indigo-100/30 text-indigo-600 rounded shrink-0">
            <Clock className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">Timing & Weekly Seasonality Analysis</h4>
            <p className="text-[11px] text-slate-500">
              Understanding shopping seasonality dictates when to publish ad-campaigns or schedule inventory drops.
            </p>
          </div>
        </div>
        <div className="bg-indigo-55/60 border border-indigo-100/45 rounded p-2.5 text-[11px] max-w-sm text-indigo-950 font-medium shrink-0">
          <span className="flex items-center gap-1 font-bold mb-0.5 text-indigo-700">
            <Info className="w-3 h-3" />
            Seasonal Tip
          </span>
          Sales frequencies are highest during dates aligning with weekend buying cohorts.
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Day of week analysis */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-emerald-50 rounded text-emerald-600 border border-emerald-100/30">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Sales by Day of the Week</h3>
              <p className="text-[11px] text-slate-400">Total gross order count split over calendar days</p>
            </div>
          </div>

          <div className="h-80 w-full">
            {transactions.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-400">No data</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dayOfWeekStats} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="day" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip formatter={(value: any) => [`${value} orders`, "Order Volume"]} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]} barSize={34}>
                    {dayOfWeekStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Month over Month progression value */}
        <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-pink-50 rounded text-pink-600 border border-pink-100/30">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Monthly Progression Tracker</h3>
              <p className="text-[11px] text-slate-400">Gross billing revenues grouped across operational months</p>
            </div>
          </div>

          <div className="h-80 w-full flex items-center justify-center">
            {transactions.length === 0 ? (
              <div className="text-slate-400 text-sm">No month stats available</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyStats} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
                  <Tooltip formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Revenue"]} />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#4338ca" 
                    strokeWidth={3.5} 
                    dot={{ r: 5, fill: "#4338ca" }} 
                    activeDot={{ r: 8 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
