export interface Transaction {
  id: string; // Internal sequential or custom ID
  orderNumber: string;
  product: string;
  price: number;
  date: string;
  paymentMethod: string;
}

export const INITIAL_TRANSACTIONS: Transaction[] = [
  { id: "1", orderNumber: "TT-1001", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-08-15", paymentMethod: "Credit Card" },
  { id: "2", orderNumber: "TT-1001", product: "Technical Performance Joggers", price: 75.00, date: "2025-08-15", paymentMethod: "Credit Card" },
  { id: "3", orderNumber: "TT-1002", product: "Classic Fit Chinos", price: 78.00, date: "2025-08-15", paymentMethod: "eWallet" },
  { id: "4", orderNumber: "TT-1003", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-08-16", paymentMethod: "Cash" },
  { id: "5", orderNumber: "TT-1004", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-08-16", paymentMethod: "Credit Card" },
  { id: "6", orderNumber: "TT-1005", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-08-17", paymentMethod: "Debit Card" },
  { id: "7", orderNumber: "TT-1005", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-08-17", paymentMethod: "eWallet" },
  { id: "8", orderNumber: "TT-1006", product: "Premium Tailored Trousers", price: 175.00, date: "2025-08-18", paymentMethod: "Credit Card" },
  { id: "9", orderNumber: "TT-1007", product: "Classic Denim Overalls", price: 115.00, date: "2025-08-18", paymentMethod: "eWallet" },
  { id: "10", orderNumber: "TT-1008", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-08-19", paymentMethod: "Debit Card" },
  { id: "11", orderNumber: "TT-1009", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-08-19", paymentMethod: "Credit Card" },
  { id: "12", orderNumber: "TT-1009", product: "Classic Fit Chinos", price: 78.00, date: "2025-08-19", paymentMethod: "Cash" },
  { id: "13", orderNumber: "TT-1010", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-08-20", paymentMethod: "Cash" },
  { id: "14", orderNumber: "TT-1011", product: "Technical Performance Joggers", price: 75.00, date: "2025-08-20", paymentMethod: "eWallet" },
  { id: "15", orderNumber: "TT-1012", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-08-21", paymentMethod: "Cash" },
  { id: "16", orderNumber: "TT-1013", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-08-21", paymentMethod: "Debit Card" },
  { id: "17", orderNumber: "TT-1014", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-08-22", paymentMethod: "Debit Card" },
  { id: "18", orderNumber: "TT-1015", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-08-22", paymentMethod: "eWallet" },
  { id: "19", orderNumber: "TT-1015", product: "Classic Fit Chinos", price: 78.00, date: "2025-08-22", paymentMethod: "Debit Card" },
  { id: "20", orderNumber: "TT-1016", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-08-23", paymentMethod: "Credit Card" },
  { id: "21", orderNumber: "TT-1017", product: "Premium Tailored Trousers", price: 175.00, date: "2025-08-24", paymentMethod: "Credit Card" },
  { id: "22", orderNumber: "TT-1018", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-08-24", paymentMethod: "Cash" },
  { id: "23", orderNumber: "TT-1018", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-08-24", paymentMethod: "Cash" },
  { id: "24", orderNumber: "TT-1019", product: "Technical Performance Joggers", price: 75.00, date: "2025-08-25", paymentMethod: "Debit Card" },
  { id: "25", orderNumber: "TT-1020", product: "Classic Denim Overalls", price: 115.00, date: "2025-08-25", paymentMethod: "Credit Card" },
  { id: "26", orderNumber: "TT-1021", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-08-26", paymentMethod: "Credit Card" },
  { id: "27", orderNumber: "TT-1022", product: "Classic Fit Chinos", price: 78.00, date: "2025-08-26", paymentMethod: "Debit Card" },
  { id: "28", orderNumber: "TT-1023", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-08-27", paymentMethod: "Debit Card" },
  { id: "29", orderNumber: "TT-1024", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-08-27", paymentMethod: "eWallet" },
  { id: "30", orderNumber: "TT-1025", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-08-28", paymentMethod: "eWallet" },
  { id: "31", orderNumber: "TT-1025", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-08-28", paymentMethod: "Debit Card" },
  { id: "32", orderNumber: "TT-1026", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-08-29", paymentMethod: "Debit Card" },
  { id: "33", orderNumber: "TT-1027", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-08-29", paymentMethod: "Credit Card" },
  { id: "34", orderNumber: "TT-1028", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-08-30", paymentMethod: "eWallet" },
  { id: "35", orderNumber: "TT-1029", product: "Premium Tailored Trousers", price: 175.00, date: "2025-08-30", paymentMethod: "Debit Card" },
  { id: "36", orderNumber: "TT-1029", product: "Classic Fit Chinos", price: 78.00, date: "2025-08-30", paymentMethod: "Debit Card" },
  { id: "37", orderNumber: "TT-1030", product: "Technical Performance Joggers", price: 75.00, date: "2025-08-31", paymentMethod: "Credit Card" },
  { id: "38", orderNumber: "TT-1031", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-01", paymentMethod: "eWallet" },
  { id: "39", orderNumber: "TT-1032", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-09-01", paymentMethod: "Credit Card" },
  { id: "40", orderNumber: "TT-1033", product: "Classic Denim Overalls", price: 115.00, date: "2025-09-02", paymentMethod: "eWallet" },
  { id: "41", orderNumber: "TT-1034", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-09-02", paymentMethod: "Cash" },
  { id: "42", orderNumber: "TT-1034", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-02", paymentMethod: "Cash" },
  { id: "43", orderNumber: "TT-1035", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-09-03", paymentMethod: "Debit Card" },
  { id: "44", orderNumber: "TT-1036", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-09-03", paymentMethod: "Credit Card" },
  { id: "45", orderNumber: "TT-1037", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-09-04", paymentMethod: "Debit Card" },
  { id: "46", orderNumber: "TT-1038", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-09-04", paymentMethod: "eWallet" },
  { id: "47", orderNumber: "TT-1039", product: "Technical Performance Joggers", price: 75.00, date: "2025-09-05", paymentMethod: "Cash" },
  { id: "48", orderNumber: "TT-1040", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-05", paymentMethod: "Debit Card" },
  { id: "49", orderNumber: "TT-1040", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-09-05", paymentMethod: "eWallet" },
  { id: "50", orderNumber: "TT-1041", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-06", paymentMethod: "Cash" },
  { id: "51", orderNumber: "TT-1042", product: "Premium Tailored Trousers", price: 175.00, date: "2025-09-06", paymentMethod: "Credit Card" },
  { id: "52", orderNumber: "TT-1043", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-09-07", paymentMethod: "Credit Card" },
  { id: "53", orderNumber: "TT-1044", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-09-08", paymentMethod: "Cash" },
  { id: "54", orderNumber: "TT-1045", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-09-08", paymentMethod: "eWallet" },
  { id: "55", orderNumber: "TT-1046", product: "Classic Denim Overalls", price: 115.00, date: "2025-09-09", paymentMethod: "Cash" },
  { id: "56", orderNumber: "TT-1047", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-09-09", paymentMethod: "eWallet" },
  { id: "57", orderNumber: "TT-1047", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-09", paymentMethod: "Cash" },
  { id: "58", orderNumber: "TT-1048", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-09-10", paymentMethod: "Credit Card" },
  { id: "59", orderNumber: "TT-1049", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-10", paymentMethod: "Cash" },
  { id: "60", orderNumber: "TT-1050", product: "Technical Performance Joggers", price: 75.00, date: "2025-09-11", paymentMethod: "Debit Card" },
  { id: "61", orderNumber: "TT-1051", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-09-12", paymentMethod: "Debit Card" },
  { id: "62", orderNumber: "TT-1052", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-09-12", paymentMethod: "eWallet" },
  { id: "63", orderNumber: "TT-1053", product: "Premium Tailored Trousers", price: 175.00, date: "2025-09-13", paymentMethod: "eWallet" },
  { id: "64", orderNumber: "TT-1054", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-09-13", paymentMethod: "Cash" },
  { id: "65", orderNumber: "TT-1054", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-09-13", paymentMethod: "Credit Card" },
  { id: "66", orderNumber: "TT-1055", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-09-14", paymentMethod: "eWallet" },
  { id: "67", orderNumber: "TT-1056", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-14", paymentMethod: "Debit Card" },
  { id: "68", orderNumber: "TT-1057", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-15", paymentMethod: "eWallet" },
  { id: "69", orderNumber: "TT-1058", product: "Classic Denim Overalls", price: 115.00, date: "2025-09-16", paymentMethod: "Debit Card" },
  { id: "70", orderNumber: "TT-1059", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-09-16", paymentMethod: "Debit Card" },
  { id: "71", orderNumber: "TT-1059", product: "Technical Performance Joggers", price: 75.00, date: "2025-09-16", paymentMethod: "Debit Card" },
  { id: "72", orderNumber: "TT-1060", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-09-17", paymentMethod: "Cash" },
  { id: "73", orderNumber: "TT-1061", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-09-17", paymentMethod: "Credit Card" },
  { id: "74", orderNumber: "TT-1062", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-09-18", paymentMethod: "eWallet" },
  { id: "75", orderNumber: "TT-1063", product: "Premium Tailored Trousers", price: 175.00, date: "2025-09-18", paymentMethod: "Credit Card" },
  { id: "76", orderNumber: "TT-1064", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-19", paymentMethod: "Credit Card" },
  { id: "77", orderNumber: "TT-1065", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-09-19", paymentMethod: "eWallet" },
  { id: "78", orderNumber: "TT-1065", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-19", paymentMethod: "eWallet" },
  { id: "79", orderNumber: "TT-1066", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-09-20", paymentMethod: "eWallet" },
  { id: "80", orderNumber: "TT-1067", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-09-21", paymentMethod: "eWallet" },
  { id: "81", orderNumber: "TT-1068", product: "Technical Performance Joggers", price: 75.00, date: "2025-09-21", paymentMethod: "Credit Card" },
  { id: "82", orderNumber: "TT-1069", product: "Classic Denim Overalls", price: 115.00, date: "2025-09-22", paymentMethod: "eWallet" },
  { id: "83", orderNumber: "TT-1070", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-09-22", paymentMethod: "Cash" },
  { id: "84", orderNumber: "TT-1071", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-09-23", paymentMethod: "Credit Card" },
  { id: "85", orderNumber: "TT-1072", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-23", paymentMethod: "eWallet" },
  { id: "86", orderNumber: "TT-1072", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-09-23", paymentMethod: "eWallet" },
  { id: "87", orderNumber: "TT-1073", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-09-24", paymentMethod: "Credit Card" },
  { id: "88", orderNumber: "TT-1074", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-24", paymentMethod: "Debit Card" },
  { id: "89", orderNumber: "TT-1075", product: "Premium Tailored Trousers", price: 175.00, date: "2025-09-25", paymentMethod: "Cash" },
  { id: "90", orderNumber: "TT-1076", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-09-26", paymentMethod: "Cash" },
  { id: "91", orderNumber: "TT-1077", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-09-26", paymentMethod: "Cash" },
  { id: "92", orderNumber: "TT-1078", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-09-27", paymentMethod: "Cash" },
  { id: "93", orderNumber: "TT-1079", product: "Technical Performance Joggers", price: 75.00, date: "2025-09-27", paymentMethod: "Debit Card" },
  { id: "94", orderNumber: "TT-1079", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-09-27", paymentMethod: "Cash" },
  { id: "95", orderNumber: "TT-1080", product: "Classic Denim Overalls", price: 115.00, date: "2025-09-28", paymentMethod: "Debit Card" },
  { id: "96", orderNumber: "TT-1081", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-09-28", paymentMethod: "Cash" },
  { id: "97", orderNumber: "TT-1082", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-09-29", paymentMethod: "Cash" },
  { id: "98", orderNumber: "TT-1083", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-09-29", paymentMethod: "eWallet" },
  { id: "99", orderNumber: "TT-1084", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-09-30", paymentMethod: "eWallet" },
  { id: "100", orderNumber: "TT-1084", product: "Classic Fit Chinos", price: 78.00, date: "2025-09-30", paymentMethod: "Debit Card" },
  { id: "101", orderNumber: "TT-1085", product: "Premium Tailored Trousers", price: 175.00, date: "2025-10-01", paymentMethod: "Credit Card" },
  { id: "102", orderNumber: "TT-1086", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-10-01", paymentMethod: "Credit Card" },
  { id: "103", orderNumber: "TT-1087", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-10-02", paymentMethod: "eWallet" },
  { id: "104", orderNumber: "TT-1088", product: "Technical Performance Joggers", price: 75.00, date: "2025-10-02", paymentMethod: "Cash" },
  { id: "105", orderNumber: "TT-1089", product: "Multi-Pocket Cargo Shorts", price: 58.00, date: "2025-10-03", paymentMethod: "Credit Card" },
  { id: "106", orderNumber: "TT-1090", product: "Drawstring Linen Trousers", price: 92.00, date: "2025-10-03", paymentMethod: "Credit Card" },
  { id: "107", orderNumber: "TT-1091", product: "Classic Denim Overalls", price: 115.00, date: "2025-10-04", paymentMethod: "Cash" },
  { id: "108", orderNumber: "TT-1092", product: "Tailored Wool Dress Trousers", price: 145.00, date: "2025-10-04", paymentMethod: "Cash" },
  { id: "109", orderNumber: "TT-1092", product: "Classic Fit Chinos", price: 78.00, date: "2025-10-04", paymentMethod: "Debit Card" },
  { id: "110", orderNumber: "TT-1093", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-10-05", paymentMethod: "Debit Card" },
  { id: "111", orderNumber: "TT-1094", product: "Striped Seersucker Trousers", price: 95.00, date: "2025-10-05", paymentMethod: "Cash" },
  { id: "112", orderNumber: "TT-1095", product: "Relaxed Fit Corduroy Trousers", price: 85.00, date: "2025-10-06", paymentMethod: "eWallet" },
  { id: "113", orderNumber: "TT-1096", product: "Premium Tailored Trousers", price: 175.00, date: "2025-10-06", paymentMethod: "Cash" },
  { id: "114", orderNumber: "TT-1097", product: "Flannel-Lined Canvas Work Pants", price: 98.00, date: "2025-10-07", paymentMethod: "Credit Card" },
  { id: "115", orderNumber: "TT-1097", product: "Slim-Fit Denim Jeans", price: 88.00, date: "2025-10-07", paymentMethod: "Debit Card" },
  { id: "116", orderNumber: "TT-1098", product: "Double-Pleated Khaki Trousers", price: 82.00, date: "2025-10-07", paymentMethod: "eWallet" }
];

export function parseCSVString(csvContent: string): Transaction[] {
  const result: Transaction[] = [];
  const lines = csvContent.split(/\r?\n/);
  
  if (lines.length <= 1) return [];

  // Identify column indices based on headers
  const headerLine = lines[0];
  const headers = headerLine.split(",").map(h => h.trim().toLowerCase());
  
  const orderNumIdx = headers.findIndex(h => h.includes("order"));
  const productIdx = headers.findIndex(h => h.includes("product"));
  const priceIdx = headers.findIndex(h => h.includes("price"));
  const dateIdx = headers.findIndex(h => h.includes("date"));
  const paymentIdx = headers.findIndex(h => h.includes("payment"));

  if (orderNumIdx === -1 || productIdx === -1 || priceIdx === -1) {
    // Return custom fallback parser
    return parseCSVLineByLineFallback(lines);
  }

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Split on comma, but respect quotes if any
    const cols = splitCSVLine(line);
    if (cols.length < 3) continue;

    const orderNo = cols[orderNumIdx] || `TT-${1000 + i}`;
    const product = cols[productIdx] || "Unknown Product";
    const priceStr = cols[priceIdx] || "0";
    const date = cols[dateIdx] || new Date().toISOString().split("T")[0];
    const payment = cols[paymentIdx] || "Cash";

    const cleanPriceStr = priceStr.replace(/[^\d.-]/g, "");
    const price = parseFloat(cleanPriceStr) || 0;

    result.push({
      id: String(i),
      orderNumber: orderNo,
      product: product,
      price: price,
      date: date,
      paymentMethod: payment
    });
  }

  return result;
}

function parseCSVLineByLineFallback(lines: string[]): Transaction[] {
  const result: Transaction[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const cols = splitCSVLine(line);
    if (cols.length < 4) continue;
    
    const priceStr = cols[2] ? cols[2].replace(/[^\d.-]/g, "") : "0";
    result.push({
      id: String(i),
      orderNumber: cols[0] || "TT-Unknown",
      product: cols[1] || "Unknown Item",
      price: parseFloat(priceStr) || 0,
      date: cols[3] || new Date().toISOString().split("T")[0],
      paymentMethod: cols[4] || "Cash"
    });
  }
  return result;
}

function splitCSVLine(line: string): string[] {
  const result: string[] = [];
  let currentWord = "";
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(currentWord.trim());
      currentWord = "";
    } else {
      currentWord += char;
    }
  }
  result.push(currentWord.trim());
  return result;
}

export function exportToCSVString(transactions: Transaction[]): string {
  const headers = ["Order Number", "Product", "Price", "Date", "Payment Method"];
  const rows = transactions.map(t => [
    t.orderNumber,
    `"${t.product.replace(/"/g, '""')}"`,
    `$${t.price.toFixed(2)}`,
    t.date,
    t.paymentMethod
  ].join(","));
  
  return [headers.join(","), ...rows].join("\n");
}
