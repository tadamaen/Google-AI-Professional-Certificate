import React, { useState, useMemo } from "react";
import { 
  INITIAL_TRANSACTIONS, Transaction, parseCSVString, exportToCSVString 
} from "./data";
import MetricCard from "./components/MetricCard";
import OverviewTab from "./components/OverviewTab";
import ProductsTab from "./components/ProductsTab";
import PaymentsTab from "./components/PaymentsTab";
import TimingTab from "./components/TimingTab";
import TransactionsTab from "./components/TransactionsTab";
import { 
  TrendingUp, BarChart3, CreditCard, Calendar, ShoppingBag, 
  RefreshCw, DollarSign, ListOrdered, Sparkles, CheckCircle2, ChevronRight, HelpCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // Primary records state
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem("analytics_store");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_TRANSACTIONS;
      }
    }
    return INITIAL_TRANSACTIONS;
  });

  // Current active viewport tab
  const [activeTab, setActiveTab] = useState<"overview" | "products" | "payments" | "timing" | "transactions">("overview");

  // Drilled down search state for item redirects
  const [drillProduct, setDrillProduct] = useState("");
  const [drillPayment, setDrillPayment] = useState("");

  const updateTransactions = (newItems: Transaction[]) => {
    setTransactions(newItems);
    localStorage.setItem("analytics_store", JSON.stringify(newItems));
  };

  const handleAddTransaction = (t: Omit<Transaction, "id">) => {
    const nextId = String(transactions.length ? Math.max(...transactions.map(item => parseInt(item.id) || 0)) + 1 : 1);
    const updated = [
      ...transactions,
      {
        id: nextId,
        ...t
      }
    ];
    updateTransactions(updated);
  };

  const handleDeleteTransaction = (id: string) => {
    const updated = transactions.filter(t => t.id !== id);
    updateTransactions(updated);
  };

  const handleRestoreDefaults = () => {
    updateTransactions(INITIAL_TRANSACTIONS);
  };

  // Dynamically calculate metrics based on contemporary records list
  const metrics = useMemo(() => {
    if (transactions.length === 0) {
      return { totalSales: "$0.00", count: 0, aov: "$0.00", activeProducts: 0, spannedRange: "No transactions loaded" };
    }
    
    const sum = transactions.reduce((acc, current) => acc + current.price, 0);
    const count = transactions.length;
    const aov = sum / count;

    // unique products
    const uniqueProds = new Set(transactions.map(t => t.product)).size;

    // dates sorting
    const sortedDates = [...transactions]
      .map(t => t.date)
      .sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    
    const spannedRange = sortedDates.length > 0 
      ? `${sortedDates[0]} to ${sortedDates[sortedDates.length - 1]}`
      : "Single date record";

    // Most popular product
    const prodCounts: Record<string, number> = {};
    transactions.forEach(t => prodCounts[t.product] = (prodCounts[t.product] || 0) + 1);
    let topProduct = "None";
    let maxCount = 0;
    Object.entries(prodCounts).forEach(([product, volume]) => {
      if (volume > maxCount) {
        maxCount = volume;
        topProduct = product;
      }
    });

    return {
      totalSales: `$${sum.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      count,
      aov: `$${aov.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      activeProducts: uniqueProds,
      spannedRange,
      topProduct
    };
  }, [transactions]);

  // Handle drill downs to redirect user to detail tabs
  const handleDrillProduct = (productName: string) => {
    setDrillProduct(productName);
    setActiveTab("products");
  };

  const handleDrillPayment = (method: string) => {
    setDrillPayment(method);
    setActiveTab("payments");
  };

  return (
    <div className="h-screen w-full bg-slate-50 flex font-sans overflow-hidden antialiased">
      
      {/* Sidebar Navigation */}
      <aside className="w-16 bg-slate-900 flex flex-col items-center py-5 gap-8 border-r border-slate-800 shrink-0 select-none z-50">
        <div className="w-8 h-8 bg-indigo-500 rounded flex items-center justify-center text-white font-bold text-lg cursor-pointer transform hover:scale-105 transition-all shadow-sm" onClick={() => setActiveTab("overview")}>
          V
        </div>
        
        {/* Navigation Mapping */}
        <nav className="flex flex-col gap-5">
          <button
            onClick={() => setActiveTab("overview")}
            className={`p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
              activeTab === "overview"
                ? "bg-slate-800 text-white border border-slate-700/50 shadow-inner"
                : "text-slate-400 hover:text-white hover:bg-slate-800/40"
            }`}
            title="Interactive Overview"
          >
            <BarChart3 className="w-5 h-5" />
          </button>

          <button
            onClick={() => { setActiveTab("products"); setDrillProduct(""); }}
            className={`p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
              activeTab === "products"
                ? "bg-slate-800 text-white border border-slate-700/50 shadow-inner"
                : "text-slate-400 hover:text-white hover:bg-slate-800/40"
            }`}
            title="Product Deep-Dive"
          >
            <ShoppingBag className="w-5 h-5" />
          </button>

          <button
            onClick={() => { setActiveTab("payments"); setDrillPayment(""); }}
            className={`p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
              activeTab === "payments"
                ? "bg-slate-800 text-white border border-slate-700/50 shadow-inner"
                : "text-slate-400 hover:text-white hover:bg-slate-800/40"
            }`}
            title="Financial Channels"
          >
            <CreditCard className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab("timing")}
            className={`p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
              activeTab === "timing"
                ? "bg-slate-800 text-white border border-slate-700/50 shadow-inner"
                : "text-slate-400 hover:text-white hover:bg-slate-800/40"
            }`}
            title="Temporal Triggers"
          >
            <Calendar className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab("transactions")}
            className={`p-2.5 rounded-lg transition-all cursor-pointer flex items-center justify-center ${
              activeTab === "transactions"
                ? "bg-slate-800 text-white border border-slate-700/50 shadow-inner"
                : "text-slate-400 hover:text-white hover:bg-slate-800/40"
            }`}
            title="Order Booklet & CSV"
          >
            <ListOrdered className="w-5 h-5" />
          </button>
        </nav>

        {/* Decorative elements to mirror design layout */}
        <div className="mt-auto p-2.5 text-slate-500 hover:text-white transition-colors cursor-pointer" title="Settings Hub">
          <svg xmlns="http://www.w3.org/2050/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        
        {/* High Density h-14 Header */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 z-40">
          <div className="flex items-center gap-3">
            <h1 className="font-semibold text-slate-800 text-[15px] tracking-tight flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
              OmniVibe Analytics Hub
            </h1>
            <div className="h-4 w-[1px] bg-slate-300"></div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
              <span>
                {activeTab === "overview" && "Global Feed"}
                {activeTab === "products" && "Product Catalog Grid"}
                {activeTab === "payments" && "Financial Gateway Channels"}
                {activeTab === "timing" && "Temporal Seasonal Triggers"}
                {activeTab === "transactions" && "Operational Order Ledger"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex bg-slate-100 rounded-md px-2.5 py-1 flex items-center gap-1.5 text-xs font-mono text-slate-600 border border-slate-200/50">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
              <span>LIVE FEED: {transactions.length} ITEMS</span>
            </div>
            <button
              onClick={handleRestoreDefaults}
              className="bg-indigo-600 text-white text-[11px] font-bold px-3 py-1.5 rounded shadow-sm hover:bg-indigo-700 transition-all flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 shrink-0" />
              ROLLBACK RECORDS
            </button>
          </div>
        </header>

        {/* Scrollable Stage Body */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4">
          
          {/* Key Metrics row - High Density version */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3.5">
            <MetricCard
              id="metric-revenue"
              title="Gross Revenue"
              value={metrics.totalSales}
              icon={DollarSign}
              description="Earned revenue aggregate"
              trend="+12.4%"
              trendType="up"
              colorClass="text-indigo-700 bg-indigo-100 border border-indigo-200/60"
              cardClassName="border border-slate-200 border-l-4 border-l-indigo-600 bg-indigo-50/15"
            />
            <MetricCard
              id="metric-orders"
              title="Checkout Volume"
              value={metrics.count}
              icon={ListOrdered}
              description="Checkout count aggregate"
              trend="ACTIVE"
              trendType="neutral"
              colorClass="text-cyan-700 bg-cyan-100 border border-cyan-200/60"
              cardClassName="border border-slate-200 border-l-4 border-l-cyan-600 bg-cyan-50/15"
            />
            <MetricCard
              id="metric-aov"
              title="Average Basket (AOV)"
              value={metrics.aov}
              icon={TrendingUp}
              description="Average basket payload"
              trend="STABLE"
              trendType="neutral"
              colorClass="text-violet-700 bg-violet-100 border border-violet-200/60"
              cardClassName="border border-slate-200 border-l-4 border-l-violet-600 bg-violet-50/15"
            />
            <MetricCard
              id="metric-catalog"
              title="Hero Catalog"
              value={metrics.topProduct}
              icon={ShoppingBag}
              description="Primary record contributor"
              trend="STAR"
              trendType="up"
              colorClass="text-rose-700 bg-rose-100 border border-rose-200/60"
              cardClassName="border border-slate-200 border-l-4 border-l-rose-600 bg-rose-50/15"
            />
            <MetricCard
              id="metric-timespan"
              title="Catalog Items"
              value={`${metrics.activeProducts} Items`}
              icon={Calendar}
              description={metrics.spannedRange}
              trend="LATEST"
              trendType="neutral"
              colorClass="text-amber-800 bg-amber-100 border border-amber-200/60"
              cardClassName="border border-slate-200 border-l-4 border-l-amber-600 bg-amber-50/15"
            />
          </div>

          {/* High Density Tabs selector (double synchronized controls inside workspace) */}
          <div className="bg-white border border-slate-200 rounded-lg p-1 shadow-sm flex flex-wrap gap-1 items-center select-none">
            <button
              onClick={() => setActiveTab("overview")}
              className={`text-xs font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ${
                activeTab === "overview"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/70"
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 shrink-0" />
              <span>Interactive Overview</span>
            </button>

            <button
              onClick={() => { setActiveTab("products"); setDrillProduct(""); }}
              className={`text-xs font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ${
                activeTab === "products"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/70"
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
              <span>Product Deep-Dive</span>
            </button>

            <button
              onClick={() => { setActiveTab("payments"); setDrillPayment(""); }}
              className={`text-xs font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ${
                activeTab === "payments"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/70"
              }`}
            >
              <CreditCard className="w-3.5 h-3.5 shrink-0" />
              <span>Financial Channels</span>
            </button>

            <button
              onClick={() => setActiveTab("timing")}
              className={`text-xs font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ${
                activeTab === "timing"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/70"
              }`}
            >
              <Calendar className="w-3.5 h-3.5 shrink-0" />
              <span>Temporal Triggers</span>
            </button>

            <button
              onClick={() => setActiveTab("transactions")}
              className={`text-xs font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 ml-auto ${
                activeTab === "transactions"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 hover:bg-slate-100/70"
              }`}
            >
              <ListOrdered className="w-3.5 h-3.5 shrink-0" />
              <span>Order Booklet & CSV</span>
            </button>
          </div>

          {/* Active View Container */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.15 }}
              className="min-h-[400px]"
            >
              {activeTab === "overview" && (
                <OverviewTab 
                  transactions={transactions} 
                  onProductClick={handleDrillProduct}
                  onPaymentMethodClick={handleDrillPayment}
                />
              )}

              {activeTab === "products" && (
                <ProductsTab 
                  transactions={transactions} 
                  initialSelectedProduct={drillProduct}
                />
              )}

              {activeTab === "payments" && (
                <PaymentsTab 
                  transactions={transactions} 
                  initialSelectedMethod={drillPayment}
                />
              )}

              {activeTab === "timing" && (
                <TimingTab transactions={transactions} />
              )}

              {activeTab === "transactions" && (
                <TransactionsTab 
                  transactions={transactions} 
                  onAddTransaction={handleAddTransaction}
                  onDeleteTransaction={handleDeleteTransaction}
                  onSetTransactions={updateTransactions}
                  onRestoreDefaults={handleRestoreDefaults}
                />
              )}
            </motion.div>
          </AnimatePresence>

        </div>

        {/* High Density Dark Monospace Footer */}
        <footer className="h-8 bg-slate-900 flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-4 text-[10px] text-slate-500 font-mono">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              API: CONNECTED
            </span>
            <span>DB: LATEST</span>
            <span>ID: 88-X9Z</span>
            <span>CLIENT_ONLY_VITE</span>
          </div>
          <div className="text-[10px] text-slate-500 font-mono">
            DASHBOARD_ENGINE_V2.0.4 - UTC {new Date().toISOString().split('T')[1].substring(0, 8)}
          </div>
        </footer>

      </main>
      
    </div>
  );
}
