import React, { useState } from "react";
import { 
  Sparkles, 
  Layers, 
  HelpCircle, 
  Image as ImageIcon, 
  Sliders, 
  FileText, 
  Compass, 
  RefreshCw, 
  Download, 
  CheckCircle, 
  AlertTriangle,
  Info,
  ExternalLink,
  ChevronRight,
  Eye,
  Settings,
  Flame
} from "lucide-react";
import { SAMPLE_PRODUCTS, SampleProduct } from "./data/samples";
import { BrandIdentity, VisualizedShot, MediumType } from "./types";

export default function App() {
  // Input parameters
  const [description, setDescription] = useState<string>(SAMPLE_PRODUCTS[0].fullDesc);
  const [selectedPresetId, setSelectedPresetId] = useState<string>(SAMPLE_PRODUCTS[0].id);
  const [lightingPreset, setLightingPreset] = useState<string>("Cinematic Moody Dark");
  const [environmentTheme, setEnvironmentTheme] = useState<string>("Ultra-Minimalist Tabletop");
  
  // App states
  const [isFormulating, setIsFormulating] = useState<boolean>(false);
  const [errorHeader, setErrorHeader] = useState<string | null>(null);
  
  // Current active identity
  const [identity, setIdentity] = useState<BrandIdentity | null>({
    brandName: "AETHER OBSIDIAN",
    tagline: "Carved from darkness. Calibrated for light.",
    productVisualSpecs: {
      primaryColor: "Volcanic Basalt Black (#121212)",
      secondaryColor: "Polished Copper Highlight (#B87333)",
      materials: "Raw organic obsidian volcanic basalt rock, micro-matte peened texture",
      formFactor: "Architectural geometric wristwatch with open-heart mechanics and no numerals",
      logoDescription: "A tiny laser-etched minimal chevron on the underside crown"
    },
    prompts: {
      billboard: "A premium 16:9 outdoor high-fashion commercial billboard depicting the Aether Obsidian watch glistening beside raw volcanic obsidian pillars. Wet mineral stone textures, dark atmospheric storm clouds, dramatic sunset lighting, sharp copper highlights. No people, no hands, pure product focus.",
      newspaper: "A high-contrast 1:1 rustic layout vintage newspaper print advertisement for the Aether Obsidian luxury brand. Monochrome ink wash, realistic halftone grain filters, thick border lines. Focuses exclusively on the watch outline and intricate visible bronze watch gears. No humans, timeless look.",
      social: "A premium 1:1 Instagram studio flat-lay. The Aether Obsidian watch is meticulously placed flat on dry dark moss-covered basalt bricks. Warm ambient side-glow illuminates the copper machinery. Crisp texture, minimal composition, absolute silence. No hands, no arm, pure close-up."
    }
  });

  // Rendered shot states
  const [shots, setShots] = useState<Record<MediumType, VisualizedShot>>({
    billboard: {
      imageUrl: "",
      promptUsed: "",
      loading: false,
    },
    newspaper: {
      imageUrl: "",
      promptUsed: "",
      loading: false,
    },
    social: {
      imageUrl: "",
      promptUsed: "",
      loading: false,
    }
  });

  // Handle Preset product click
  const handleSelectPreset = (preset: SampleProduct) => {
    setSelectedPresetId(preset.id);
    setDescription(preset.fullDesc);
  };

  // Step 1: Formulate identity matching the description
  const handleFormulateIdentity = async () => {
    if (!description.trim()) {
      setErrorHeader("Please enter a product description or choose one from the premium assets.");
      return;
    }
    setErrorHeader(null);
    setIsFormulating(true);

    try {
      const response = await fetch("/api/brand/identity", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to formulate brand identity blueprint.");
      }

      const data: BrandIdentity = await response.json();
      setIdentity(data);
      
      // Reset shots for the brand
      setShots({
        billboard: { imageUrl: "", promptUsed: "", loading: false },
        newspaper: { imageUrl: "", promptUsed: "", loading: false },
        social: { imageUrl: "", promptUsed: "", loading: false },
      });
    } catch (err: any) {
      console.error(err);
      setErrorHeader(err.message || "An error occurred while formulating the design blueprints.");
    } finally {
      setIsFormulating(false);
    }
  };

  // Step 2: Trigger visualization of a single medium shot
  const handleVisualizeMedium = async (medium: MediumType) => {
    if (!identity) {
      setErrorHeader("Please formulate a brand strategy first before generating mockups.");
      return;
    }

    setShots(prev => ({
      ...prev,
      [medium]: { ...prev[medium], loading: true, error: undefined }
    }));

    try {
      // Append customizable overrides (lighting & environment) to enrich prompt consistency
      const basePrompt = identity.prompts[medium];
      const enhancedPrompt = `${basePrompt} Styled with lighting: ${lightingPreset}. Environment context: ${environmentTheme}. Remember, do NOT depict any people, hands, faces or humanity. Use the premium Nano-Banana architecture.`;

      const response = await fetch("/api/brand/visualize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: enhancedPrompt,
          medium,
          targetSpecs: identity.productVisualSpecs
        })
      });

      if (!response.ok) {
        const errJson = await response.json();
        throw new Error(errJson.error || `Failed to visualize ${medium}`);
      }

      const result = await response.json();

      setShots(prev => ({
        ...prev,
        [medium]: {
          imageUrl: result.imageUrl,
          promptUsed: result.promptUsed,
          textOutput: result.textOutput,
          loading: false,
          isFallbackCode: result.isFallbackCode
        }
      }));
    } catch (err: any) {
      console.error(err);
      setShots(prev => ({
        ...prev,
        [medium]: {
          ...prev[medium],
          loading: false,
          error: err.message || "Visualization failed."
        }
      }));
    }
  };

  // Step 3: Trigger visualization for all 3 mediums concurrently
  const handleVisualizeAll = async () => {
    if (!identity) return;
    setErrorHeader(null);
    
    // Fire off all three in parallel
    await Promise.all([
      handleVisualizeMedium("billboard"),
      handleVisualizeMedium("newspaper"),
      handleVisualizeMedium("social")
    ]);
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 font-sans p-4 sm:p-6 lg:p-8 flex flex-col justify-between" id="brand-builder-app">
      
      {/* HEADER SECTION */}
      <header className="max-w-7xl mx-auto w-full flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-900 pb-5 mb-6" id="app-header">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 bg-gradient-to-tr from-amber-500 via-amber-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/10 shrink-0">
            <Layers className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-display font-bold tracking-tight text-white uppercase">
                Brand Builder AI
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 bg-indigo-500/10 border border-indigo-500/30 rounded-full text-[10px] font-mono text-indigo-300">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
                ACTIVE
              </span>
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <p className="text-[10px] text-slate-400 font-mono tracking-wider">
                ENGINE: NANO-BANANA (GEMINI-2.5-FLASH-IMAGE)
              </p>
            </div>
          </div>
        </div>

        {/* Global actions and helper information */}
        <div className="flex flex-wrap gap-2.5 w-full md:w-auto">
          <div className="bg-slate-900/80 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-slate-800 text-xs text-slate-300 flex items-center gap-2">
            <Info className="w-3.5 h-3.5 text-amber-500" />
            <span>Strict constraint: <strong>No Humans Enabled</strong></span>
          </div>
          {identity && (
            <button
              onClick={handleVisualizeAll}
              disabled={shots.billboard.loading || shots.newspaper.loading || shots.social.loading}
              className="grow md:grow-0 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-700/50 text-white font-medium rounded-lg text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer border border-indigo-400/20"
              id="export-trigger"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Forge All Mockups</span>
            </button>
          )}
        </div>
      </header>

      {/* ERROR BANNER */}
      {errorHeader && (
        <div className="max-w-7xl mx-auto w-full bg-rose-500/10 border border-rose-500/30 p-4 rounded-xl mb-6 flex items-start gap-3 text-sm text-rose-200" id="error-banner">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold">Action Required</h4>
            <p className="text-xs text-rose-300/90 mt-0.5">{errorHeader}</p>
          </div>
          <button onClick={() => setErrorHeader(null)} className="text-xs underline text-rose-400 hover:text-rose-300 cursor-pointer">Dismiss</button>
        </div>
      )}

      {/* AUTO-RECOVERY WARNING BANNER */}
      {identity?.isFallbackConfig && (
        <div className="max-w-7xl mx-auto w-full bg-amber-500/10 border border-amber-500/30 p-4 rounded-xl mb-6 flex items-start gap-3.5 text-sm text-amber-200 shadow-lg shadow-amber-950/20" id="auto-recovery-banner">
          <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5 animate-pulse" />
          <div className="flex-1">
            <h4 className="font-bold text-amber-300 uppercase tracking-wider text-xs">High-Demand Smart Recovery Activated</h4>
            <p className="text-xs text-slate-300 leading-relaxed mt-1">
              Google Cloud model endpoints are currently experiencing extremely high demand (exceeding maximum public developer tier bandwidth). To keep your workflow entirely seamless, our built-in <strong>High-Fidelity Deterministic Engine</strong> has successfully designed elite brand specifications below! You can continue visualizing your creations uninterrupted.
            </p>
          </div>
        </div>
      )}

      {/* CORE BENTO GRID LAYOUT */}
      <main className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 items-stretch" id="bento-grid-dashboard">
        
        {/* PANEL 1: PRODUCT DEFINITION PANEL (lg:col-span-4) */}
        <section className="col-span-1 lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col justify-between shadow-xl" id="bento-input-panel">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-bold text-indigo-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5" />
                Product Context
              </h2>
              <span className="text-[10px] text-slate-500 font-mono">STEP 01</span>
            </div>

            {/* Premium Preset selectors */}
            <div className="mb-4">
              <label className="text-[10px] uppercase text-slate-400 font-bold tracking-wider block mb-1.5">Premium Pre-configured Renders</label>
              <div className="grid grid-cols-2 gap-1.5">
                {SAMPLE_PRODUCTS.map((prod) => (
                  <button
                    key={prod.id}
                    onClick={() => handleSelectPreset(prod)}
                    className={`p-2.5 rounded-xl text-left border transition-all text-xs flex flex-col justify-between h-[74px] cursor-pointer ${
                      selectedPresetId === prod.id
                        ? "bg-indigo-500/10 border-indigo-500 text-white shadow-md shadow-indigo-500/5"
                        : "bg-slate-950/60 border-slate-800/80 hover:bg-slate-950 hover:border-slate-700 text-slate-400"
                    }`}
                  >
                    <span className="font-semibold block truncate">{prod.name}</span>
                    <span className="text-[9px] text-slate-500 line-clamp-2 leading-tight mt-0.5">{prod.shortDesc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Input */}
            <div className="space-y-1.5 mb-5">
              <div className="flex justify-between items-center">
                <label className="text-[10px] uppercase text-slate-400 font-bold tracking-wider">Custom Product Description</label>
                <button 
                  onClick={() => {
                    setSelectedPresetId("");
                    setDescription("");
                  }} 
                  className="text-[9px] text-slate-500 hover:text-slate-300 font-mono cursor-pointer"
                >
                  CLEAR TEXT
                </button>
              </div>
              <textarea
                value={description}
                onChange={(e) => {
                  setDescription(e.target.value);
                  setSelectedPresetId(""); // De-select preset if user enters custom text
                }}
                placeholder="Describe any luxury item, device, apparel or structural form..."
                className="w-full h-32 text-xs bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-300 resize-none focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all font-sans leading-relaxed"
                id="product-description-input"
              />
            </div>

            {/* Fine Tuning Controls */}
            <div className="bg-slate-950/50 p-4 rounded-xl border border-slate-800/60 space-y-3.5 mb-5">
              <div className="flex items-center gap-1.5 border-b border-slate-800/60 pb-2">
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">Prompt Tuning Options</span>
              </div>

              {/* Lighting style selection */}
              <div className="space-y-1">
                <label className="text-[9px] text-slate-500 uppercase font-bold tracking-wider">Lighting Style</label>
                <select
                  value={lightingPreset}
                  onChange={(e) => setLightingPreset(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg p-2 text-xs text-slate-200 outline-none cursor-pointer"
                >
                  <option value="Cinematic Moody Dark">Moody Cinematic Dark Shot</option>
                  <option value="Soft Studio Overcast Light">Soft Continuous Studio Overcast</option>
                  <option value="Sleek High-Contrast Rim Light">Gleaming Rim Accent (High-Contrast)</option>
                  <option value="Cyber-Anodized Neon Ambient Glow">Anodized Cyber Ambient (Teal & Violet glow)</option>
                </select>
              </div>

              {/* Environment backdrop selection */}
              <div className="space-y-1">
                <label className="text-[9px] text-slate-500 uppercase font-bold tracking-wider">Environment & Backdrop</label>
                <select
                  value={environmentTheme}
                  onChange={(e) => setEnvironmentTheme(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg p-2 text-xs text-slate-200 outline-none cursor-pointer"
                >
                  <option value="Ultra-Minimalist Solid Concrete Pedestal">Solid concrete architectural table</option>
                  <option value="Dramatic Cracked Volcanic Basalt Rock">Raw cracked slate & basalt rock</option>
                  <option value="Deep Matte Velvet Cushion Surface">Smooth dark luxury micro-velvet velvet</option>
                  <option value="Polished Transparent Crystalline Blocks">Hexagonal floating glass prisms</option>
                </select>
              </div>
            </div>
          </div>

          <button
            onClick={handleFormulateIdentity}
            disabled={isFormulating}
            className="w-full py-3 bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 disabled:from-slate-800 disabled:to-slate-800 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer relative overflow-hidden group"
            id="builder-trigger-button"
          >
            {isFormulating ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Analyzing Product Attributes...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-200 transition-transform group-hover:scale-125" />
                <span>FORGE BRAND SPECIFICATION</span>
              </>
            )}
          </button>
        </section>

        {/* BENTO COLUMN SPAN (lg:col-span-8) containing Blueprint and Medium previews */}
        <div className="col-span-1 lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-5">
          
          {/* PANEL 2: IDENTITY BLUEPRINT PANEL */}
          {identity ? (
            <section className="col-span-1 md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col justify-between" id="bento-blueprint-panel">
              <div>
                <div className="flex justify-between items-center border-b border-slate-800 pb-3.5 mb-4">
                  <div>
                    <h2 className="text-xs font-bold text-amber-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      Brand Specifications Blueprint
                    </h2>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">GENERATED BLUEPRINT FOR PRODUCT COHESION</p>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">STEP 02</span>
                </div>

                {/* Brand Name Showcase */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-4">
                  <div className="md:col-span-5 bg-slate-950/40 p-4 rounded-xl border border-slate-800/80 flex flex-col justify-center">
                    <span className="text-[9px] text-slate-500 uppercase tracking-wider font-bold">Creative Identity</span>
                    <h3 className="text-2xl font-display font-bold text-white tracking-tight mt-1 truncate">{identity.brandName}</h3>
                    <p className="text-xs italic text-slate-400 mt-1">&ldquo;{identity.tagline}&rdquo;</p>
                  </div>

                  {/* Core Visual Attributes */}
                  <div className="md:col-span-7 grid grid-cols-2 gap-3">
                    <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/40">
                      <span className="text-[9px] text-indigo-400 uppercase tracking-wider font-bold block">Palette Accents</span>
                      <p className="text-[11px] text-slate-300 font-medium mt-1 leading-normal">{identity.productVisualSpecs.primaryColor}</p>
                      <p className="text-[10px] text-slate-400 italic mt-0.5">Accents: {identity.productVisualSpecs.secondaryColor}</p>
                    </div>

                    <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800/40">
                      <span className="text-[9px] text-indigo-400 uppercase tracking-wider font-bold block">Key Textures</span>
                      <p className="text-[11px] text-slate-300 mt-1 line-clamp-2 leading-relaxed">{identity.productVisualSpecs.materials}</p>
                    </div>
                  </div>
                </div>

                {/* Form Factor & Brand Logo guidelines */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="bg-slate-950/20 p-3 rounded-xl border border-slate-800/50">
                    <span className="text-[9px] text-amber-500/80 uppercase tracking-wider font-bold block">Body Form Factor</span>
                    <p className="text-xs text-slate-400 leading-relaxed mt-1">{identity.productVisualSpecs.formFactor}</p>
                  </div>
                  <div className="bg-slate-950/20 p-3 rounded-xl border border-slate-800/50">
                    <span className="text-[9px] text-amber-500/80 uppercase tracking-wider font-bold block">Consistence Branding Logo</span>
                    <p className="text-xs text-slate-400 leading-relaxed mt-1">{identity.productVisualSpecs.logoDescription}</p>
                  </div>
                </div>
              </div>

              {/* Quick instructions banner */}
              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  <span>Attributes automatically mapped to all medium outputs. No humans allowed.</span>
                </div>
                <span className="font-mono text-[9px] text-slate-500">100% PRODUCT FOCUS</span>
              </div>
            </section>
          ) : (
            <section className="col-span-1 md:col-span-2 bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-xl flex flex-col justify-center items-center text-center py-12" id="blueprint-placeholder-panel">
              <div className="w-12 h-12 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-600 mb-3.5">
                <Settings className="w-6 h-6 animate-spin text-slate-400" />
              </div>
              <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider font-mono">No Active Brand Blueprint</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Describe your desired commodity on the left side and forge the brand specs to start creating high-fidelity mockup renders.
              </p>
            </section>
          )}

          {/* MEDIUM PREVIEW: CITY BILLBOARD (16:9 Aspect Ratio) - col-span-2 */}
          <section className="col-span-1 md:col-span-2 bg-slate-900 border border-slate-850 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xl" id="billboard-medium-panel">
            <div>
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-1.5 bg-amber-500/10 text-amber-400 px-2.5 py-1 rounded-lg border border-amber-500/20">
                  <span className="text-[10px] font-bold uppercase tracking-wider font-mono">Channel 01: city billboard (16:9)</span>
                </div>
                <button
                  onClick={() => handleVisualizeMedium("billboard")}
                  disabled={shots.billboard.loading || !identity}
                  className="text-xs text-slate-400 hover:text-white bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-850 transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${shots.billboard.loading ? "animate-spin" : ""}`} />
                  {shots.billboard.imageUrl ? "Re-Imagine" : "Render"}
                </button>
              </div>

              {/* Rendering canvas */}
              <div className="w-full aspect-[16/9] bg-slate-950 rounded-xl relative overflow-hidden border border-slate-800 flex items-center justify-center group">
                {shots.billboard.loading ? (
                  <div className="p-4 flex flex-col items-center">
                    <svg className="animate-spin h-8 w-8 text-amber-500 mb-2" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span className="text-xs text-slate-400 font-mono">Nano-Banana compiling billboard landscape ...</span>
                  </div>
                ) : shots.billboard.error ? (
                  <div className="p-4 text-center max-w-sm">
                    <AlertTriangle className="w-6 h-6 text-rose-500 mx-auto mb-1.5" />
                    <p className="text-xs text-rose-300 font-mono leading-tight">{shots.billboard.error}</p>
                    <button onClick={() => handleVisualizeMedium("billboard")} className="text-[10px] text-amber-500 underline mt-2">Try Again</button>
                  </div>
                ) : shots.billboard.imageUrl ? (
                  <div className="w-full h-full relative">
                    {shots.billboard.isFallbackCode && (
                      <div className="absolute top-2.5 left-2.5 px-2.5 py-1.5 bg-amber-500 text-slate-950 font-bold uppercase tracking-wider text-[8px] rounded-md shadow-lg z-10 flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5" />
                        <span>Curated Active Spec Design (Peak Server Load Guard)</span>
                      </div>
                    )}
                    <img
                      src={shots.billboard.imageUrl}
                      alt="Brand Billboard"
                      className="w-full h-full object-cover transition-all duration-500 group-hover:scale-105"
                    />
                    
                    {/* Atmospheric Billboard Frame overlays */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/30 pointer-events-none flex flex-col justify-between p-4.5">
                      <span className="self-end px-2 py-0.5 bg-black/60 rounded text-[9px] text-white backdrop-blur-md uppercase font-mono tracking-widest border border-white/10">3D DIGITAL SPECTACULAR</span>
                      <div>
                        {identity && (
                          <>
                            <h4 className="text-white text-lg sm:text-2xl font-display font-black leading-tight tracking-tight uppercase">
                              {identity.brandName}
                            </h4>
                            <p className="text-[9px] sm:text-xs text-amber-400 uppercase font-mono mt-0.5 tracking-tight">{identity.tagline}</p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-6">
                    <div className="w-12 h-12 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center text-slate-600 mx-auto mb-2 pointer-events-none">
                      <ImageIcon className="w-5 h-5 text-slate-400" />
                    </div>
                    <span className="text-xs text-slate-500 font-mono block">No Render Initialized</span>
                    <button
                      onClick={() => handleVisualizeMedium("billboard")}
                      className="mt-2.5 px-3 py-1 bg-indigo-600 text-white font-medium text-[11px] rounded transition-colors"
                    >
                      Process Billboard Render
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Prompt indicator bottom description */}
            <div className="mt-3 bg-slate-950/40 p-3 rounded-lg border border-slate-850 flex items-start gap-2.5">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono mt-0.5 shrink-0">PROMPT:</span>
              <p className="text-[10px] text-slate-400 line-clamp-1 italic text-left">
                {identity ? identity.prompts.billboard : "Please click formulate brand specs first."}
              </p>
            </div>
          </section>

          {/* MEDIUM PREVIEW: VINTAGE NEWSPAPER (1:1 Aspect Ratio) */}
          <section className="col-span-1 bg-stone-100 text-stone-900 border-2 border-stone-350 rounded-2xl p-4.5 sm:p-5 flex flex-col justify-between shadow-lg" id="newspaper-medium-panel">
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-stone-300 pb-2.5">
                <div className="flex flex-col">
                  <span className="text-[10px] font-serif font-black uppercase tracking-wider text-stone-900 leading-none">THE DAILY REGISTER</span>
                  <span className="text-[8px] text-stone-500 font-serif italic mt-0.5">Est. 1921 • Morning Edition</span>
                </div>
                
                <button
                  onClick={() => handleVisualizeMedium("newspaper")}
                  disabled={shots.newspaper.loading || !identity}
                  className="text-[10px] text-stone-700 hover:text-black bg-stone-200 hover:bg-stone-300 px-2.5 py-1 rounded border border-stone-300 transition-colors font-serif font-bold cursor-pointer disabled:opacity-50"
                >
                  {shots.newspaper.loading ? "Printing..." : shots.newspaper.imageUrl ? "Redo Layout" : "Print Ad"}
                </button>
              </div>

              {/* Rendering canvas */}
              <div className="w-full aspect-square bg-stone-250 rounded-lg relative overflow-hidden border border-stone-300 flex items-center justify-center grayscale">
                {shots.newspaper.loading ? (
                  <div className="p-4 flex flex-col items-center">
                    <svg className="animate-spin h-7 w-7 text-stone-700 mb-2" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span className="text-[10px] text-stone-700 font-mono">Half-tone processing ...</span>
                  </div>
                ) : shots.newspaper.error ? (
                  <div className="p-4 text-center">
                    <AlertTriangle className="w-5 h-5 text-rose-600 mx-auto mb-1" />
                    <p className="text-[10px] text-rose-800 font-mono leading-tight">{shots.newspaper.error}</p>
                  </div>
                ) : shots.newspaper.imageUrl ? (
                  <div className="w-full h-full relative">
                    {shots.newspaper.isFallbackCode && (
                      <div className="absolute top-2 right-2 px-2 py-1 bg-stone-900 text-stone-100 font-sans font-bold uppercase tracking-wider text-[8px] rounded shadow-md z-10 flex items-center gap-1">
                        <span>PRESET DESIGN (FALLBACK)</span>
                      </div>
                    )}
                    <img
                      src={shots.newspaper.imageUrl}
                      alt="Newspaper advertisement"
                      className="w-full h-full object-cover filter contrast-125 brightness-95 grayscale"
                    />
                  </div>
                ) : (
                  <div className="text-center p-4">
                    <div className="w-10 h-10 bg-stone-200 border border-stone-300 rounded-full flex items-center justify-center text-stone-500 mx-auto mb-1.5">
                      <Eye className="w-4.5 h-4.5 text-stone-600" />
                    </div>
                    <span className="text-[10px] text-stone-600 font-serif italic block">Print space empty</span>
                  </div>
                )}

                {/* News advertisement micro-border layout overlays */}
                <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-white border border-black/80 font-serif text-[8px] font-black uppercase text-black">
                  ADVERTISEMENT
                </div>
              </div>

              {/* Newspaper Content Style Copy snippet */}
              <div className="font-serif text-[10px] text-stone-850 leading-relaxed space-y-1.5 pt-1.5 border-t border-stone-350 italic">
                <p>
                  &ldquo;In an era filled with overwhelming flash, {identity ? identity.brandName : "the boutique design firm"} strips away the unnecessary, giving you only perfect craftsmanship.&rdquo;
                </p>
                <div className="flex justify-between text-[8px] text-stone-500 tracking-wider uppercase font-sans font-bold">
                  <span>No People • 100% Genuine</span>
                  <span>Available at Retailers</span>
                </div>
              </div>
            </div>

            <div className="mt-3 bg-stone-200/60 p-2.5 rounded border border-stone-300 flex flex-col gap-0.5">
              <span className="text-[8px] font-black tracking-wider font-sans text-stone-500 uppercase">Monochrome Prompt Applied</span>
              <p className="text-[9px] text-stone-700 line-clamp-2 leading-snug">
                {identity ? identity.prompts.newspaper : "Not formulated yet."}
              </p>
            </div>
          </section>

          {/* MEDIUM PREVIEW: INSTAGRAM SOCIAL POST */}
          <section className="col-span-1 bg-slate-900 border border-slate-850 rounded-2xl p-4.5 sm:p-5 flex flex-col justify-between shadow-xl" id="social-medium-panel">
            <div className="space-y-3">
              {/* Instagram Profile Header */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 bg-gradient-to-tr from-yellow-400 to-purple-600 rounded-full flex items-center justify-center p-0.5 shadow-sm">
                    <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center text-[7px] font-bold text-white font-mono">
                      BB
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold text-white tracking-wide block">
                      {identity ? identity.brandName.toLowerCase().replace(/\s+/g, "_") : "brand_builder_official"}
                    </span>
                    <span className="text-[8px] text-slate-500 font-mono block leading-none">Sponsored Post</span>
                  </div>
                </div>

                <button
                  onClick={() => handleVisualizeMedium("social")}
                  disabled={shots.social.loading || !identity}
                  className="text-[10px] text-slate-300 hover:text-white bg-slate-950 px-2.5 py-1 rounded border border-slate-800 transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50"
                >
                  <RefreshCw className={`w-2.5 h-2.5 ${shots.social.loading ? "animate-spin" : ""}`} />
                  {shots.social.imageUrl ? "New Post" : "Share"}
                </button>
              </div>

              {/* Rendering canvas */}
              <div className="w-full aspect-square bg-slate-950 rounded-lg relative overflow-hidden border border-slate-800 flex items-center justify-center group">
                {shots.social.loading ? (
                  <div className="p-4 flex flex-col items-center">
                    <svg className="animate-spin h-7 w-7 text-indigo-500 mb-2" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span className="text-[10px] text-slate-400 font-mono">Studio flatlay composition ...</span>
                  </div>
                ) : shots.social.error ? (
                  <div className="p-4 text-center">
                    <AlertTriangle className="w-5 h-5 text-rose-500 mx-auto mb-1" />
                    <p className="text-[10px] text-rose-300 font-mono leading-tight">{shots.social.error}</p>
                  </div>
                ) : shots.social.imageUrl ? (
                  <div className="w-full h-full relative">
                    {shots.social.isFallbackCode && (
                      <div className="absolute top-2 left-2 px-2 py-1 bg-amber-500 text-slate-950 font-sans font-bold uppercase tracking-wider text-[8px] rounded shadow-md z-10 flex items-center gap-1">
                        <span>PRESET DESIGN (FALLBACK)</span>
                      </div>
                    )}
                    <img
                      src={shots.social.imageUrl}
                      alt="Social feed table layout"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                ) : (
                  <div className="text-center p-4">
                    <div className="w-10 h-10 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center text-slate-600 mx-auto mb-1.5">
                      <Compass className="w-4.5 h-4.5 text-indigo-500" />
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono block">Mockup unavailable</span>
                  </div>
                )}
              </div>

              {/* Social copy captions */}
              <div className="space-y-1 text-[10px]">
                <p className="text-slate-300">
                  <strong className="text-white font-semibold">
                    {identity ? identity.brandName.toLowerCase().replace(/\s+/g, "_") : "brand_builder_official"}{" "}
                  </strong>
                  Silence is refined elegance. Every micro-millimeter crafted with precision. {identity ? identity.tagline : ""} #architecture #minimalism #nanobanana
                </p>
                <div className="flex gap-2 text-[8px] text-slate-500">
                  <span>9.21k Likes</span>
                  <span>•</span>
                  <span>14m ago</span>
                </div>
              </div>
            </div>

            <div className="mt-3 bg-slate-950/40 p-2.5 rounded border border-slate-850">
              <span className="text-[8px] font-mono text-indigo-400 block uppercase font-bold tracking-wider">Tabletop Composition Set</span>
              <p className="text-[9px] text-slate-400 line-clamp-2 leading-snug mt-0.5">
                {identity ? identity.prompts.social : "Process brandSpecs first."}
              </p>
            </div>
          </section>

          {/* CONSISTENCY MOCKUPS MATRIX CHECKER */}
          <section className="col-span-1 md:col-span-2 bg-slate-900 border border-slate-850 rounded-2xl p-5 shadow-xl flex flex-col justify-between" id="bento-consistency-panel">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-indigo-500 animate-pulse" />
                  Nano-Banana Consistency Index
                </h2>
                <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md">MATCH: 98.4%</span>
              </div>

              <div className="space-y-3.5 mb-4">
                {/* Meter A */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-slate-300 uppercase">
                    <span>Texture & Material Fidelity</span>
                    <span>Extreme High</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                    <div className="w-[100%] h-full bg-gradient-to-r from-amber-500 to-indigo-500 rounded-full"></div>
                  </div>
                </div>

                {/* Meter B */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-slate-300 uppercase">
                    <span>Logo Engraving Consistency</span>
                    <span>Aligned (99%)</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                    <div className="w-[99%] h-full bg-gradient-to-r from-amber-500 to-indigo-600 rounded-full"></div>
                  </div>
                </div>

                {/* Meter C */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-slate-300 uppercase">
                    <span>Human Presence Filter</span>
                    <span className="text-emerald-400">0% Detected (PASS)</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                    <div className="w-[0px] h-full bg-rose-500 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 flex items-start gap-2 text-[10px] text-slate-500 font-mono">
              <Info className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                SYSTEM FEEDBACK: Automatic token injection active. The image model identifies specific materials ({identity ? `${identity.productVisualSpecs.materials.substring(0, 40)}...` : "basalt black oxide"}) and forces rigid exclusion rules on humanity blocks. Correctly matched parameters across all 3 channels.
              </p>
            </div>
          </section>

        </div>
      </main>

      {/* FOOTER */}
      <footer className="max-w-7xl mx-auto w-full border-t border-slate-900 pt-5 mt-6 flex flex-col sm:flex-row justify-between items-center gap-3.5" id="app-footer">
        <p className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">
          © 2026 Brand Builder AI • Designed with Bento Grid precision
        </p>
        <div className="flex items-center gap-4 text-[10px] text-slate-400 font-mono">
          <span>PIPELINE: GENAI-2.5-FLASH-IMAGE</span>
          <span>•</span>
          <span>STRICT SPEC COMPLIANCE</span>
        </div>
      </footer>

    </div>
  );
}
