import React from "react";
import { BrandIdentity } from "../types";
import { Sparkles, Layers, Sliders, Palette, FileText, CheckCircle } from "lucide-react";

interface IdentityCardProps {
  identity: BrandIdentity;
  onVisualizeAll: () => void;
  visualizingAll: boolean;
  someGenerated: boolean;
}

export const IdentityCard: React.FC<IdentityCardProps> = ({
  identity,
  onVisualizeAll,
  visualizingAll,
  someGenerated,
}) => {
  const { brandName, tagline, productVisualSpecs, prompts } = identity;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-xl overflow-hidden animate-fade-in" id="brand-identity-card">
      {/* Top Banner Accent */}
      <div className="h-2 bg-gradient-to-r from-amber-500 via-stone-700 to-indigo-600" />

      <div className="p-6 md:p-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 border-b border-gray-100 pb-6 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 rounded-full text-xs font-semibold text-amber-700 uppercase tracking-widest font-mono mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Brand Identity Formulated
            </div>
            <h2 className="text-3xl md:text-4xl font-display font-semibold tracking-tight text-gray-900">
              {brandName}
            </h2>
            <p className="text-gray-500 font-medium italic mt-1 font-sans">
              &ldquo;{tagline}&rdquo;
            </p>
          </div>

          <button
            onClick={onVisualizeAll}
            disabled={visualizingAll}
            className="self-start md:self-center px-6 py-3.5 bg-gray-900 hover:bg-gray-800 disabled:bg-gray-400 text-white font-medium rounded-xl transition-all duration-200 shadow-md hover:shadow-lg disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer w-full md:w-auto"
            id="visualize-all-button"
          >
            {visualizingAll ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Generating Mockups...
              </>
            ) : someGenerated ? (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                Re-Generate All Shots
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                Generate All Shots (Nano-Banana)
              </>
            )}
          </button>
        </div>

        {/* Breakdown Specifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          
          {/* Visual Specs / Design Specs Card */}
          <div className="space-y-6">
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <Palette className="w-4 h-4 text-gray-500" />
              1. Visual Blueprints
            </h3>

            <div className="bg-gray-50 rounded-xl p-5 space-y-4 border border-gray-100">
              {/* Colors */}
              <div>
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest font-mono">Color Palette</span>
                <div className="flex flex-wrap gap-3 mt-1.5">
                  <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm text-sm">
                    <span className="w-4 h-4 rounded px-1.5 bg-amber-500 inline-block border border-gray-300 shadow-inner" style={{ backgroundColor: productVisualSpecs.primaryColor.match(/#[0-9a-fA-F]{6}/)?.[0] || "#D97706" }} />
                    <span className="font-mono text-xs font-medium text-gray-700">{productVisualSpecs.primaryColor}</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm text-sm">
                    <span className="w-4 h-4 rounded px-1.5 bg-indigo-500 inline-block border border-gray-300 shadow-inner" style={{ backgroundColor: productVisualSpecs.secondaryColor.match(/#[0-9a-fA-F]{6}/)?.[0] || "#4F46E5" }} />
                    <span className="font-mono text-xs font-medium text-gray-700">{productVisualSpecs.secondaryColor}</span>
                  </div>
                </div>
              </div>

              {/* Form Factor */}
              <div className="border-t border-gray-200/60 pt-3">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest font-mono">Form Factor & Shape</span>
                <p className="text-sm text-gray-800 mt-1 leading-relaxed font-sans">{productVisualSpecs.formFactor}</p>
              </div>

              {/* Materials */}
              <div className="border-t border-gray-200/60 pt-3">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest font-mono">Primary Materials</span>
                <p className="text-sm text-gray-800 mt-1 leading-relaxed font-sans">{productVisualSpecs.materials}</p>
              </div>

              {/* Branding / Logo */}
              <div className="border-t border-gray-200/60 pt-3">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest font-mono">Minimal Branding Logo Engraving</span>
                <p className="text-sm text-gray-800 mt-1 leading-relaxed font-sans">{productVisualSpecs.logoDescription}</p>
              </div>
            </div>
          </div>

          {/* Prompt Set specifications */}
          <div className="space-y-6">
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 font-mono flex items-center gap-2">
              <FileText className="w-4 h-4 text-gray-500" />
              2. Consistently Injected Prompts
            </h3>

            <div className="space-y-4">
              {/* Billboard Prompt */}
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-amber-200 transition-colors">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded uppercase tracking-wider font-mono">Billboard App (16:9)</span>
                  <span className="text-[11px] text-gray-400 font-mono">No Humans Enabled</span>
                </div>
                <p className="text-xs text-gray-600 line-clamp-2 italic leading-relaxed">&ldquo;{prompts.billboard}&rdquo;</p>
              </div>

              {/* Newspaper Prompt */}
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-amber-200 transition-colors">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded uppercase tracking-wider font-mono">Newspaper print (1:1)</span>
                  <span className="text-[11px] text-gray-400 font-mono">Monochrome Aesthetic</span>
                </div>
                <p className="text-xs text-gray-600 line-clamp-2 italic leading-relaxed">&ldquo;{prompts.newspaper}&rdquo;</p>
              </div>

              {/* Social Prompt */}
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-amber-200 transition-colors">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-semibold text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded uppercase tracking-wider font-mono">Social Flat-lay (1:1)</span>
                  <span className="text-[11px] text-gray-400 font-mono">Premium Composition</span>
                </div>
                <p className="text-xs text-gray-600 line-clamp-2 italic leading-relaxed">&ldquo;{prompts.social}&rdquo;</p>
              </div>
            </div>
          </div>

        </div>

        {/* Security Rule / Constraint Acknowledging Banner */}
        <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-emerald-900">Human-Free Consistency Directives Active</h4>
            <p className="text-xs text-emerald-700 mt-1 leading-relaxed">
              Every generation request automatically injects structured specifications describing the design materials and color pallet. Prompt filters are appended with strict negative tags preventing rendering of human figures, silhouettes, or hands, optimizing clean product-only shots on the Nano-Banana model.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
