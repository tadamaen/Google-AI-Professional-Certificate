/**
 * Types representing the Brand Identity and Visual Configuration.
 */

export interface ProductVisualSpecs {
  primaryColor: string;
  secondaryColor: string;
  materials: string;
  formFactor: string;
  logoDescription: string;
}

export interface MediumPrompts {
  billboard: string;
  newspaper: string;
  social: string;
}

export interface BrandIdentity {
  brandName: string;
  tagline: string;
  productVisualSpecs: ProductVisualSpecs;
  prompts: MediumPrompts;
  isFallbackConfig?: boolean;
}

export interface VisualizedShot {
  imageUrl: string;
  promptUsed: string;
  textOutput?: string;
  loading: boolean;
  error?: string;
  isFallbackCode?: boolean;
}

export type MediumType = "billboard" | "newspaper" | "social";
