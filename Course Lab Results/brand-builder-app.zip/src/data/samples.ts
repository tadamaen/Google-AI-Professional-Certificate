export interface SampleProduct {
  id: string;
  name: string;
  shortDesc: string;
  fullDesc: string;
}

export const SAMPLE_PRODUCTS: SampleProduct[] = [
  {
    id: "watch",
    name: "Aether Obsidian Watch",
    shortDesc: "Primal volcanic basalt & copper mechanics.",
    fullDesc: "A minimalist premium wristwatch carved out of raw obsidian volcanic basalt rock, featuring a polished open-heart copper clockwork mechanism, no numbers on the dial, a matte black heavy-grain leather strap, and a single tiny glowing amber LED inset near the 12 o'clock marker. Sleek, tactile, premium design.",
  },
  {
    id: "bottle",
    name: "Hydro-Chamber Flask",
    shortDesc: "Matte titanium & magnetic liquid flow.",
    fullDesc: "An luxury double-walled thermos flask constructed from shot-peened matte grade-5 titanium. It features a geometric architectural cap, a subtle glowing teal temperature collar indicator, and a sleek integrated textured grey silica carry strap. The finish is micro-textured, highly scuff-resistant, and presents clean industrial lines with absolutely no visible welds.",
  },
  {
    id: "speaker",
    name: "Prism Acoustic Core",
    shortDesc: "Acrylic monolithic floor speaker.",
    fullDesc: "A monolithic hexagonal floor-standing audio speaker crafted from perfectly transparent solid thick crystalline acrylic. Inside, the glowing golden metallic speaker cone and electromagnetic coils are fully visible in the center, suspended in mid-air. Zero wires visible, resting on a heavy-brushed aluminum hexagonal base.",
  },
  {
    id: "sneaker",
    name: "Vektor Light Runners",
    shortDesc: "Recycled mesh & translucent polymer heels.",
    fullDesc: "A pair of high-performance architectural running shoes engineered with thick-knit off-white recycled mesh fabric. The heels rest on a sculptural, hollow, semi-translucent neon-lime energetic thermoplastic elastomer spring-ring. Completely clean construction, geometric structural grid lines, no logos on the exterior except a tiny debossed arrow near the tip.",
  }
];
