import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-loaded Gemini client to prevent crashing on boot if key is missing
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY is not defined. Please add it in the Secrets panel (Settings > Secrets) to enable AI decision-making.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// API endpoint for analyzing a decision
app.post("/api/analyze", async (req, res) => {
  try {
    const { decision, optionA, optionB, context } = req.body;

    if (!decision || typeof decision !== "string" || !decision.trim()) {
       res.status(400).json({ error: "Decision title is required." });
       return;
    }

    const ai = getGeminiClient();

    let prompt = `You are a world-class strategic analyst and neutral decision solver. Your goal is to break a tie and make a highly practical, rational choice for the user.

Decision statement: "${decision.trim()}"`;

    if (optionA && optionA.trim()) {
      prompt += `\nOption A under consideration: "${optionA.trim()}"`;
    }
    if (optionB && optionB.trim()) {
      prompt += `\nOption B under consideration: "${optionB.trim()}"`;
    }
    if (context && context.trim()) {
      prompt += `\nUser's background context and personal constraints: "${context.trim()}"`;
    }

    prompt += `\n\nPerform three types of robust decision analysis:
1. Analytical Pros & Cons: Provide a minimum of 4 distinct Pros and 4 distinct Cons for the overall decision or Options.
2. SWOT Analysis: Detail Strengths, Weaknesses, Opportunities, and Threats (at least 3 items each) specifically mapped to this choice.
3. Comparison Table: Build a structured matrix comparing key dimensional criteria (e.g. Long-term Value, Stress/Effort, Accessibility, Cost, Growth Potential) with corresponding descriptive cells for each option.
4. Objective Tiebreaker Verdict: Formulate a final recommendation to confidently break the tie. Write deep, practical, tailored logic for the recommendation and quantify a tie-breaking confidence score from 0 to 100.

Ensure your tone is premium, objective, consultative, and highly custom to the user's scenario. Avoid generic placeholders.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            decisionTitle: {
              type: Type.STRING,
              description: "The main decision statement analyzed."
            },
            prosCons: {
              type: Type.OBJECT,
              properties: {
                pros: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Tailored advantages of proceeding or choosing the optimal options"
                },
                cons: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Drawbacks, costs, or calculated risks to consider"
                }
              },
              required: ["pros", "cons"]
            },
            swot: {
              type: Type.OBJECT,
              properties: {
                strengths: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Internal strengths, immediate benefits, control-based factors"
                },
                weaknesses: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Internal weaknesses, required sacrifices, personal hurdles"
                },
                opportunities: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "External future opportunities, secondary gains, expansion avenues"
                },
                threats: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "External threats, market factors, force majeure, long-term costs"
                }
              },
              required: ["strengths", "weaknesses", "opportunities", "threats"]
            },
            comparisonTable: {
              type: Type.OBJECT,
              properties: {
                headers: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Header array for the 2D matrix (first item is 'Factor' or 'Rating Matrix', subsequent items are option names like 'Option A', 'Option B')"
                },
                rows: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  description: "Rows of string comparisons. Example: ['Cost', 'Free / Open-Source', '$50/mo subscription']"
                }
              },
              required: ["headers", "rows"]
            },
            tiebreakerVerdict: {
              type: Type.OBJECT,
              properties: {
                recommendation: {
                  type: Type.STRING,
                  description: "The final direct recommendation to break the tie"
                },
                reasoning: {
                  type: Type.STRING,
                  description: "Strategic explanation of why the recommended path offers the optimal net-benefit or mitigates the highest risk."
                },
                confidenceScore: {
                  type: Type.INTEGER,
                  description: "Integer score from 0 (completely uncertain) to 100 (absolutely definitive recommendation) reflecting the weight of arguments."
                }
              },
              required: ["recommendation", "reasoning", "confidenceScore"]
            }
          },
          required: ["decisionTitle", "prosCons", "swot", "comparisonTable", "tiebreakerVerdict"]
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response generated from the AI model.");
    }

    const parsedResult = JSON.parse(resultText);
    res.json(parsedResult);
  } catch (error: any) {
    console.error("Analysis API failed:", error);
    res.status(500).json({ error: error?.message || "An error occurred during decision analysis." });
  }
});

async function startServer() {
  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
