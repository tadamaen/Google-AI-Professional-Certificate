/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ProsConsData {
  pros: string[];
  cons: string[];
}

export interface SwotData {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface ComparisonTableData {
  headers: string[];
  rows: string[][];
}

export interface TiebreakerVerdictData {
  recommendation: string;
  reasoning: string;
  confidenceScore: number;
}

export interface DecisionAnalysisResult {
  decisionTitle: string;
  prosCons: ProsConsData;
  swot: SwotData;
  comparisonTable: ComparisonTableData;
  tiebreakerVerdict: TiebreakerVerdictData;
}

export interface SavedDecision {
  id: string;
  timestamp: string;
  decision: string;
  optionA?: string;
  optionB?: string;
  context?: string;
  result: DecisionAnalysisResult;
}
