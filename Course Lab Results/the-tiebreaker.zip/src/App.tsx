/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Scale, 
  Sparkles, 
  History, 
  HelpCircle, 
  PlusCircle, 
  TrendingUp, 
  Compass, 
  Layers, 
  Award, 
  RefreshCw,
  XCircle,
  FileText
} from "lucide-react";
import { DecisionForm } from "./components/DecisionForm";
import { VerdictDisplay } from "./components/VerdictDisplay";
import { ProsConsDisplay } from "./components/ProsConsDisplay";
import { SwotDisplay } from "./components/SwotDisplay";
import { ComparisonDisplay } from "./components/ComparisonDisplay";
import { SavedDecisionsList } from "./components/SavedDecisionsList";
import { DecisionAnalysisResult, SavedDecision } from "./types";

const LOCAL_STORAGE_KEY = "the_tiebreaker_saved_decisions";

export default function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [activeTab, setActiveTab] = useState<"verdict" | "proscons" | "swot" | "comparison">("verdict");
  
  // Stored analysis results
  const [currentResult, setCurrentResult] = useState<DecisionAnalysisResult | null>(null);
  const [currentInputs, setCurrentInputs] = useState<{
    decision: string;
    optionA?: string;
    optionB?: string;
    context?: string;
  } | null>(null);
  const [activeDecisionId, setActiveDecisionId] = useState<string | null>(null);

  // History list
  const [savedDecisions, setSavedDecisions] = useState<SavedDecision[]>([]);
  const [apiError, setApiError] = useState<string | null>(null);

  // Read saved history on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as SavedDecision[];
        setSavedDecisions(parsed);
        if (parsed.length > 0) {
          // Default load the most recent decision
          setCurrentResult(parsed[0].result);
          setCurrentInputs({
            decision: parsed[0].decision,
            optionA: parsed[0].optionA,
            optionB: parsed[0].optionB,
            context: parsed[0].context
          });
          setActiveDecisionId(parsed[0].id);
        }
      }
    } catch (e) {
      console.error("Failed to load saved decisions:", e);
    }
  }, []);

  // Loading stepper updates
  useEffect(() => {
    if (!isLoading) return;
    const interval = setInterval(() => {
      setLoadingStep((prev) => (prev + 1) % 4);
    }, 2400);
    return () => clearInterval(interval);
  }, [isLoading]);

  const loadingMessages = [
    "Formulating decision parameters and alignment weights...",
    "Brainstorming critical Pros & Cons based on specific context...",
    "Drafting Strengths, Gaps, Opportunities, and Threats...",
    "Weighing mathematical factors and resolving the final recommendation..."
  ];

  const handleAnalyze = async (inputs: { decision: string; optionA: string; optionB: string; context: string }) => {
    setIsLoading(true);
    setLoadingStep(0);
    setApiError(null);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inputs),
      });

      if (!response.ok) {
        const errJson = await response.json();
        throw new Error(errJson.error || `HTTP ${response.status} Error`);
      }

      const resultData = (await response.json()) as DecisionAnalysisResult;
      
      setCurrentResult(resultData);
      setCurrentInputs(inputs);

      // Save into historical localStorage
      const newSaved: SavedDecision = {
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toISOString(),
        decision: inputs.decision,
        optionA: inputs.optionA || undefined,
        optionB: inputs.optionB || undefined,
        context: inputs.context || undefined,
        result: resultData,
      };

      const updatedList = [newSaved, ...savedDecisions];
      setSavedDecisions(updatedList);
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedList));
      setActiveDecisionId(newSaved.id);

      // Automatically switch to the verdict tab to present the result
      setActiveTab("verdict");
    } catch (err: any) {
      console.error(err);
      setApiError(err?.message || "An unexpected error occurred while analyzing the tradeoff.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectSaved = (saved: SavedDecision) => {
    setCurrentResult(saved.result);
    setCurrentInputs({
      decision: saved.decision,
      optionA: saved.optionA,
      optionB: saved.optionB,
      context: saved.context
    });
    setActiveDecisionId(saved.id);
    setActiveTab("verdict");
    setApiError(null);
  };

  const handleDeleteSaved = (id: string) => {
    const updated = savedDecisions.filter((s) => s.id !== id);
    setSavedDecisions(updated);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));

    if (activeDecisionId === id) {
      if (updated.length > 0) {
        handleSelectSaved(updated[0]);
      } else {
        setCurrentResult(null);
        setCurrentInputs(null);
        setActiveDecisionId(null);
      }
    }
  };

  const handleClearAll = () => {
    if (window.confirm("Are you sure you want to clear your entire decision history?")) {
      setSavedDecisions([]);
      localStorage.removeItem(LOCAL_STORAGE_KEY);
      setCurrentResult(null);
      setCurrentInputs(null);
      setActiveDecisionId(null);
    }
  };

  const handleStartNew = () => {
    setCurrentResult(null);
    setCurrentInputs(null);
    setActiveDecisionId(null);
    setApiError(null);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans antialiased">
      {/* Header Bar */}
      <header id="app-header" className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0 relative overflow-hidden">
              <div className="w-4 h-[2px] bg-white rotate-45 translate-y-[1px]"></div>
              <div className="w-4 h-[2px] bg-white -rotate-45 -translate-y-[1px] absolute"></div>
            </div>
            <div>
              <span className="font-bold text-lg sm:text-xl tracking-tight italic text-slate-900 block uppercase font-display">THE TIEBREAKER</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-4 text-xs font-mono font-semibold tracking-wider text-slate-400">
              <span className="text-indigo-600">DASHBOARD</span>
              <span>•</span>
              <span>DECISIONS HISTORY LOG</span>
            </div>
            <div className="flex items-center gap-2">
              {currentResult && (
                <button
                  id="start-new-header-btn"
                  onClick={handleStartNew}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg cursor-pointer transition-colors border-0"
                >
                  <PlusCircle className="w-4 h-4" />
                  New Analysis
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row gap-8">
        
        {/* Left Side: Form, Presets, and History Log */}
        <div className="w-full lg:w-[380px] shrink-0 space-y-6">
          {/* Form */}
          <DecisionForm onSubmit={handleAnalyze} isLoading={isLoading} />
          
          {/* Saved History Log */}
          <SavedDecisionsList
            decisions={savedDecisions}
            activeId={activeDecisionId}
            onSelect={handleSelectSaved}
            onDelete={handleDeleteSaved}
            onClearAll={handleClearAll}
          />
        </div>

        {/* Right Side: Analysis Display and Viewports */}
        <div className="flex-1 space-y-6">
          <div id="results-container" className="h-full">
            {isLoading ? (
              /* Loading Backdrop with Professional Stepper */
              <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xs flex flex-col items-center justify-center min-h-[480px] text-center space-y-6 animate-pulse">
                <div className="relative w-16 h-16 flex items-center justify-center bg-slate-900 text-indigo-400 rounded-full border border-slate-800">
                  <RefreshCw className="w-8 h-8 animate-spin" />
                </div>
                <div className="space-y-2 max-w-md">
                  <h3 className="font-display font-semibold text-slate-800 text-lg">Analyzing Tradeoffs</h3>
                  <p className="text-slate-500 text-xs sm:text-sm h-12 flex items-center justify-center">
                    {loadingMessages[loadingStep]}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${loadingStep === 0 ? "bg-indigo-600" : "bg-slate-200"}`} />
                  <span className={`w-2 h-2 rounded-full ${loadingStep === 1 ? "bg-indigo-600" : "bg-slate-200"}`} />
                  <span className={`w-2 h-2 rounded-full ${loadingStep === 2 ? "bg-indigo-600" : "bg-slate-200"}`} />
                  <span className={`w-2 h-2 rounded-full ${loadingStep === 3 ? "bg-indigo-600" : "bg-slate-200"}`} />
                </div>
              </div>
            ) : apiError ? (
              /* API Fail Panel */
              <div id="error-fallback" className="bg-red-50/40 border border-red-100 rounded-2xl p-6 md:p-8 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center">
                    <XCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-slate-800 text-base sm:text-lg">Analysis Unsuccessful</h3>
                    <p className="text-red-700/80 text-xs">Verify your setup credentials or try again.</p>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-4 border border-slate-100 text-slate-700 font-mono text-xs overflow-auto max-h-48 leading-relaxed">
                  {apiError}
                </div>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Make sure you have added a valid <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-600">GEMINI_API_KEY</code> to the secrets panel by opening the <strong>Settings &gt; Secrets</strong> menu on Google AI Studio.
                </p>
              </div>
            ) : currentResult ? (
              /* Core Multi-view Decision Panel */
              <div id="decision-matrix-card" className="space-y-6">
                
                {/* Heading details */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-xs space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-semibold">
                        CURRENT ACTIVE CASE
                      </span>
                      <h2 id="active-decision-headline" className="text-xl sm:text-2xl font-display font-bold text-slate-900 leading-tight">
                        {currentResult.decisionTitle}
                      </h2>
                    </div>
                  </div>

                  {currentInputs?.context && (
                    <div className="bg-slate-50 border border-slate-100/50 p-4 rounded-xl space-y-1.5">
                      <h4 className="text-[10px] font-mono text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5" />
                        Provided Context Constraints
                      </h4>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic">
                        "{currentInputs.context}"
                      </p>
                    </div>
                  )}

                  {/* Responsive view switcher tabs */}
                  <div className="flex items-center overflow-x-auto border-b border-slate-100 pt-2 gap-1 scrollbar-none">
                    <button
                      id="tab-btn-verdict"
                      onClick={() => setActiveTab("verdict")}
                      className={`px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                        activeTab === "verdict"
                          ? "border-slate-900 text-slate-900 font-bold"
                          : "border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200"
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <Award className="w-4 h-4" />
                        Tiebreaker Verdict
                      </span>
                    </button>

                    <button
                      id="tab-btn-proscons"
                      onClick={() => setActiveTab("proscons")}
                      className={`px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                        activeTab === "proscons"
                          ? "border-slate-900 text-slate-900 font-bold"
                          : "border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200"
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <TrendingUp className="w-4 h-4" />
                        Pros &amp; Cons List
                      </span>
                    </button>

                    <button
                      id="tab-btn-swot"
                      onClick={() => setActiveTab("swot")}
                      className={`px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                        activeTab === "swot"
                          ? "border-slate-900 text-slate-900 font-bold"
                          : "border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200"
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <Compass className="w-4 h-4" />
                        SWOT Analysis
                      </span>
                    </button>

                    <button
                      id="tab-btn-comparison"
                      onClick={() => setActiveTab("comparison")}
                      className={`px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
                        activeTab === "comparison"
                          ? "border-slate-900 text-slate-900 font-bold"
                          : "border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200"
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <Layers className="w-4 h-4" />
                        Comparison Table
                      </span>
                    </button>
                  </div>
                </div>

                {/* Viewport for active rendering */}
                <div id="viewport-grid" className="space-y-6">
                  {activeTab === "verdict" && (
                    <VerdictDisplay verdict={currentResult.tiebreakerVerdict} />
                  )}

                  {activeTab === "proscons" && (
                    <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-xs">
                      <ProsConsDisplay data={currentResult.prosCons} />
                    </div>
                  )}

                  {activeTab === "swot" && (
                    <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-xs">
                      <SwotDisplay data={currentResult.swot} />
                    </div>
                  )}

                  {activeTab === "comparison" && (
                     <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-xs">
                       <ComparisonDisplay data={currentResult.comparisonTable} />
                     </div>
                  )}
                </div>

              </div>
            ) : (
              /* Fresh onboarding screen */
              <div id="empty-state" className="bg-white border border-slate-200 rounded-2xl p-8 md:p-12 text-center flex flex-col items-center justify-center min-h-[480px] space-y-6 shadow-xs">
                <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                  <Scale className="w-7 h-7" />
                </div>
                <div className="space-y-2 max-w-md">
                  <h3 className="text-xl font-display font-semibold text-slate-800 tracking-tight">AI Decision Architect</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    Struggling with a difficult professional tradeoff, a coding dilemma, or a real-estate choice? Describe your scenarios on the left or load a demo preset to see analytical matrices and the final Tiebreaker verdict.
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-xl text-left pt-4">
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/50 space-y-1">
                    <span className="font-mono text-[10px] font-semibold text-indigo-600 block uppercase">Step 01</span>
                    <h5 className="font-semibold text-slate-700 text-xs">A&amp;B Options</h5>
                    <p className="text-slate-500 text-[11px] leading-normal">Enter opposing options and relevant baseline context variables.</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/50 space-y-1">
                    <span className="font-mono text-[10px] font-semibold text-indigo-600 block uppercase">Step 02</span>
                    <h5 className="font-semibold text-slate-700 text-xs">Generate Matrix</h5>
                    <p className="text-slate-500 text-[11px] leading-normal">Model generates full-spectrum SWOT, comparative tables, and logs pros/cons.</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/50 space-y-1">
                    <span className="font-mono text-[10px] font-semibold text-indigo-600 block uppercase">Step 03</span>
                    <h5 className="font-semibold text-slate-700 text-xs">Break the Tie</h5>
                    <p className="text-slate-500 text-[11px] leading-normal">Inspect AI recommendation with detailed objective confidence scoring.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

      </main>

      <footer className="bg-white border-t border-slate-200 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-400 font-mono tracking-wide">
          © 2026 THE TIEBREAKER — COMPREHENSIVE DECISION ANALYSIS ENGINE
        </div>
      </footer>
    </div>
  );
}
