/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { History, Trash2, Calendar, FileCheck, ArrowUpRight } from "lucide-react";
import { SavedDecision } from "../types";

interface SavedDecisionsListProps {
  decisions: SavedDecision[];
  activeId: string | null;
  onSelect: (decision: SavedDecision) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
}

export function SavedDecisionsList({
  decisions,
  activeId,
  onSelect,
  onDelete,
  onClearAll
}: SavedDecisionsListProps) {
  if (decisions.length === 0) {
    return (
      <div className="bg-slate-50/50 rounded-2xl p-6 text-center border border-slate-200/50">
        <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-slate-500 font-medium text-sm">No Decisions Analyzed Yet</p>
        <p className="text-slate-400 text-xs mt-0.5">Your analyzed decisions will appear here for easy reference.</p>
      </div>
    );
  }

  const formatDate = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div id="saved-decisions-panel" className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-slate-600" />
          <h3 className="font-display font-semibold text-slate-800">History Log</h3>
          <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full text-[10px] font-mono font-medium">
            {decisions.length}
          </span>
        </div>
        <button
          onClick={onClearAll}
          id="clear-all-decisions-btn"
          className="text-[10px] text-red-500 hover:text-red-700 hover:underline uppercase tracking-wider font-mono font-semibold bg-transparent border-0 cursor-pointer"
        >
          Clear All
        </button>
      </div>

      <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
        {decisions.map((item) => {
          const isActive = item.id === activeId;
          return (
            <div
              key={item.id}
              id={`decision-log-item-${item.id}`}
              className={`group flex items-start gap-3 p-3.5 rounded-xl border transition-all text-left relative ${
                isActive
                  ? "bg-slate-50 border-slate-900 ring-1 ring-slate-900"
                  : "bg-white hover:bg-slate-50/50 border-slate-200 hover:border-slate-300"
              }`}
            >
              <button
                onClick={() => onSelect(item)}
                className="grow text-left absolute inset-0 rounded-xl z-0 cursor-pointer"
                aria-label={`Open decision: ${item.decision}`}
              />
              
              <div className="z-10 relative flex-1">
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400">
                  <Calendar className="w-3 h-3 text-slate-300" />
                  <span>{formatDate(item.timestamp)}</span>
                  {item.result?.tiebreakerVerdict?.confidenceScore && (
                    <>
                      <span>•</span>
                      <span className="text-indigo-500 font-semibold">
                        {item.result.tiebreakerVerdict.confidenceScore}% conf
                      </span>
                    </>
                  )}
                </div>

                <h4 className="text-slate-800 font-medium text-xs sm:text-sm mt-1 line-clamp-2 leading-snug group-hover:text-indigo-600 transition-colors">
                  {item.decision}
                </h4>

                {(item.optionA || item.optionB) && (
                  <div className="flex items-center gap-1.5 mt-1.5">
                    {item.optionA && (
                      <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-sm max-w-[100px] truncate">
                        {item.optionA}
                      </span>
                    )}
                    {item.optionA && item.optionB && <span className="text-[9px] text-slate-300">vs</span>}
                    {item.optionB && (
                      <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-sm max-w-[100px] truncate">
                        {item.optionB}
                      </span>
                    )}
                  </div>
                )}
                
                <div className="flex items-center gap-1 mt-2 text-[10px] text-emerald-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
                  <FileCheck className="w-3 h-3" />
                  <span>Inspect Results</span>
                  <ArrowUpRight className="w-2.5 h-2.5" />
                </div>
              </div>

              <button
                id={`delete-btn-${item.id}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(item.id);
                }}
                className="z-20 relative p-1.5 border-0 hover:bg-rose-50 text-slate-400 hover:text-rose-500 rounded-lg cursor-pointer shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
