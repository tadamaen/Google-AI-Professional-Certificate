/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { SwotData } from "../types";

interface SwotDisplayProps {
  data: SwotData;
}

export function SwotDisplay({ data }: SwotDisplayProps) {
  const strengths = data?.strengths || [];
  const weaknesses = data?.weaknesses || [];
  const opportunities = data?.opportunities || [];
  const threats = data?.threats || [];

  return (
    <div id="swot-card-container" className="bg-slate-900 rounded-2xl flex flex-col overflow-hidden text-white shadow-xl shadow-indigo-500/5 border border-slate-800">
      {/* SWOT Heading */}
      <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
        <div className="space-y-0.5">
          <h2 className="font-bold text-sm tracking-tight text-white uppercase font-mono">SWOT Strategic Framework</h2>
          <p className="text-[10px] text-slate-400">Matrix view of internal capability and external factors</p>
        </div>
        <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse"></div>
      </div>

      {/* SWOT Quadrant Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 sm:p-5">
        {/* Strengths */}
        <div className="p-3.5 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors">
          <p className="text-[10px] font-black uppercase text-indigo-400 tracking-wider mb-2">Strengths (S)</p>
          {strengths.length === 0 ? (
            <p className="text-[11px] text-slate-400 italic">No advantages noted.</p>
          ) : (
            <ul className="space-y-1.5 text-slate-200">
              {strengths.map((item, idx) => (
                <li key={idx} className="text-xs leading-normal flex items-start gap-1.5">
                  <span className="text-indigo-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Weaknesses */}
        <div className="p-3.5 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors">
          <p className="text-[10px] font-black uppercase text-rose-400 tracking-wider mb-2">Weaknesses (W)</p>
          {weaknesses.length === 0 ? (
            <p className="text-[11px] text-slate-400 italic">No liabilities noted.</p>
          ) : (
            <ul className="space-y-1.5 text-slate-200">
              {weaknesses.map((item, idx) => (
                <li key={idx} className="text-xs leading-normal flex items-start gap-1.5">
                  <span className="text-rose-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Opportunities */}
        <div className="p-3.5 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors">
          <p className="text-[10px] font-black uppercase text-emerald-400 tracking-wider mb-2">Opportunities (O)</p>
          {opportunities.length === 0 ? (
            <p className="text-[11px] text-slate-400 italic">No opportunities evaluated.</p>
          ) : (
            <ul className="space-y-1.5 text-slate-200">
              {opportunities.map((item, idx) => (
                <li key={idx} className="text-xs leading-normal flex items-start gap-1.5">
                  <span className="text-emerald-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Threats */}
        <div className="p-3.5 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors">
          <p className="text-[10px] font-black uppercase text-amber-400 tracking-wider mb-2">Threats (T)</p>
          {threats.length === 0 ? (
            <p className="text-[11px] text-slate-400 italic">No external risks flagged.</p>
          ) : (
            <ul className="space-y-1.5 text-slate-200">
              {threats.map((item, idx) => (
                <li key={idx} className="text-xs leading-normal flex items-start gap-1.5">
                  <span className="text-amber-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
