/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ComparisonTableData } from "../types";

interface ComparisonDisplayProps {
  data: ComparisonTableData;
}

export function ComparisonDisplay({ data }: ComparisonDisplayProps) {
  const headers = data?.headers || [];
  const rows = data?.rows || [];

  if (headers.length === 0 || rows.length === 0) {
    return (
       <div className="bg-slate-50 rounded-xl p-6 text-center border border-slate-100 text-slate-400 italic text-sm">
         No comparison matrix data available.
       </div>
    );
  }

  return (
    <div id="comparison-section" className="bg-white rounded-2xl border border-slate-200 flex flex-col overflow-hidden shadow-xs">
      {/* Table Header Wrapper */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
        <div className="space-y-0.5">
          <h2 className="font-mono text-xs font-bold uppercase tracking-tight text-slate-800">Direct Options Comparison</h2>
          <p className="text-[10px] text-slate-400">Comparing criteria factors across options side by side</p>
        </div>
        <div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
      </div>

      <div className="overflow-x-auto w-full">
        <table className="w-full text-xs sm:text-sm text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100">
              {headers.map((header, idx) => (
                <th key={idx} className="p-3.5 font-medium text-slate-500 uppercase tracking-widest font-mono text-[10px]">
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="text-slate-600 divide-y divide-slate-100">
            {rows.map((row, rowIdx) => (
              <tr key={rowIdx} className="hover:bg-slate-50/20 transition-colors">
                {row.map((cell, cellIdx) => {
                  const isSpecialText = cellIdx === 2 || cell.includes("High") || cell.includes("Accelerated");
                  return (
                    <td 
                      key={cellIdx} 
                      className={`p-3.5 border-b border-slate-50 ${
                        cellIdx === 0 
                          ? "font-semibold text-slate-800" 
                          : isSpecialText 
                            ? "text-indigo-600 font-medium" 
                            : "text-slate-600"
                      }`}
                    >
                      {cell}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Decorative summary bar */}
      <div className="p-4 bg-slate-50/50 border-t border-slate-100">
        <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex">
          <div className="h-full bg-slate-300 w-[45%]"></div>
          <div className="h-full bg-indigo-500 w-[55%]"></div>
        </div>
        <div className="flex justify-between mt-2 text-[10px] font-bold text-slate-400 font-mono">
          <span>OPTION A METRIC ALIGNMENT: 45%</span>
          <span>OPTION B METRIC ALIGNMENT: 55%</span>
        </div>
      </div>
    </div>
  );
}

