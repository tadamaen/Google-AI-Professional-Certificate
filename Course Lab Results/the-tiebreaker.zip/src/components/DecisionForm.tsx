/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sparkles, HelpCircle, FileText, ArrowRight } from "lucide-react";

interface DecisionFormProps {
  onSubmit: (data: { decision: string; optionA: string; optionB: string; context: string }) => void;
  isLoading: boolean;
}

const PRESETS = [
  {
    name: "💻 Tech Stack (Rust vs Go)",
    decision: "Which language should I choose for our upcoming high-performance backend microservices?",
    optionA: "Go (Golang)",
    optionB: "Rust",
    context: "Our team has strong TypeScript experience. We need rapid time-to-market, simple horizontal scaling, and ultra-low memory footprints.",
  },
  {
    name: "🏡 Home: Buy vs Rent",
    decision: "Should we buy a townhouse near suburbs or continue renting our city-center apartment?",
    optionA: "Purchase a suburban townhouse",
    optionB: "Renew our lease and rent in city-center",
    context: "We are an active young couple considering starting a family in 2-3 years, but we hate long commutes.",
  },
  {
    name: "🚀 Specialization: Cloud vs Frontend",
    decision: "Should I focus my personal study time on Cloud Architecture or advanced Frontend Engineering?",
    optionA: "Cloud Architecture & Devops",
    optionB: "Advanced UX & Frontend Engineering",
    context: "Current role is general full-stack. I have 4 hours/week of study time. Looking to maximize salary increment in the next 12 months.",
  }
];

export function DecisionForm({ onSubmit, isLoading }: DecisionFormProps) {
  const [decision, setDecision] = useState("");
  const [optionA, setOptionA] = useState("");
  const [optionB, setOptionB] = useState("");
  const [context, setContext] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!decision.trim()) return;
    onSubmit({
      decision: decision.trim(),
      optionA: optionA.trim(),
      optionB: optionB.trim(),
      context: context.trim(),
    });
  };

  const handleApplyPreset = (preset: typeof PRESETS[0]) => {
    setDecision(preset.decision);
    setOptionA(preset.optionA);
    setOptionB(preset.optionB);
    setContext(preset.context);
  };

  return (
    <div id="decision-form-panel" className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 md:p-8 space-y-8">
      <div>
        <h2 className="text-xl font-display font-semibold text-slate-800 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-500" />
          Describe Your Choice
        </h2>
        <p className="text-slate-500 text-sm mt-1">
          Provide the decision title and optional parameters to let AI weigh the pros, cons, SWOT variables, and break the tie.
        </p>
      </div>

      {/* Preset Badges */}
      <div className="space-y-2">
        <label className="text-xs font-mono font-medium text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <HelpCircle className="w-3.5 h-3.5" />
          Quick Demo Presets
        </label>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((preset, idx) => (
            <button
              key={idx}
              id={`preset-btn-${idx}`}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-50 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg border border-slate-200 hover:border-indigo-200 transition-all duration-150 cursor-pointer text-left"
            >
              {preset.name}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Decision Input */}
        <div className="space-y-2">
          <label htmlFor="decision-input" className="block text-sm font-medium text-slate-700">
            What is the primary decision or tradeoff? <span className="text-red-500">*</span>
          </label>
          <input
            id="decision-input"
            type="text"
            required
            value={decision}
            onChange={(e) => setDecision(e.target.value)}
            disabled={isLoading}
            placeholder="e.g. Should I transition into a freelance consulting business?"
            className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-800 placeholder-slate-400 transition-colors"
          />
        </div>

        {/* Options Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label htmlFor="option-a-input" className="block text-sm font-medium text-slate-700">
              Option A <span className="text-slate-400 text-xs font-normal">(Optional)</span>
            </label>
            <input
              id="option-a-input"
              type="text"
              value={optionA}
              onChange={(e) => setOptionA(e.target.value)}
              disabled={isLoading}
              placeholder="e.g. Start consulting full-time"
              className="w-full px-4 py-2 bg-slate-50/50 hover:bg-slate-50 focus:bg-white rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-800 placeholder-slate-400 transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="option-b-input" className="block text-sm font-medium text-slate-700">
              Option B <span className="text-slate-400 text-xs font-normal">(Optional)</span>
            </label>
            <input
              id="option-b-input"
              type="text"
              value={optionB}
              onChange={(e) => setOptionB(e.target.value)}
              disabled={isLoading}
              placeholder="e.g. Keep secure full-time job"
              className="w-full px-4 py-2 bg-slate-50/50 hover:bg-slate-50 focus:bg-white rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-800 placeholder-slate-400 transition-colors"
            />
          </div>
        </div>

        {/* Context Input */}
        <div className="space-y-2">
          <label htmlFor="context-input" className="block text-sm font-medium text-slate-700">
            Background Context & Personal Values <span className="text-slate-400 text-xs font-normal">(Optional)</span>
          </label>
          <textarea
            id="context-input"
            rows={3}
            value={context}
            onChange={(e) => setContext(e.target.value)}
            disabled={isLoading}
            placeholder="Help the AI align with your specific style. Describe your current baseline, experience, top priorities (e.g. flexibility vs safety), budget limits, or other constraints."
            className="w-full px-4 py-3 bg-slate-50/50 hover:bg-slate-50 focus:bg-white rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-800 placeholder-slate-400 transition-colors resize-y text-sm"
          />
        </div>

        {/* Action Button */}
        <button
          id="submit-decision-btn"
          type="submit"
          disabled={isLoading || !decision.trim()}
          className="w-full py-3.5 px-6 rounded-xl font-medium text-white flex items-center justify-center gap-2 cursor-pointer transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed bg-slate-900 border border-slate-800 hover:bg-indigo-600 hover:border-indigo-700 focus:ring-4 focus:ring-indigo-100 shadow-xs"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Resolving Tradeoffs via AI...
            </>
          ) : (
            <>
              <FileText className="w-4 h-4" />
              Analyze Decision & Break Tie
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>
    </div>
  );
}
