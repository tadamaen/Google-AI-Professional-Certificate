/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ProsConsData } from "../types";

interface ProsConsDisplayProps {
  data: ProsConsData;
}

export function ProsConsDisplay({ data }: ProsConsDisplayProps) {
  const pros = data?.pros || [];
  const cons = data?.cons || [];

  return (
    <div id="pros-cons-grid" className="shadow-xs rounded-2xl border border-slate-200 flex flex-col overflow-hidden bg-white">
      {/* Header */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
        <div className="space-y-0.5">
          <h2 className="font-mono text-xs font-bold uppercase tracking-tight text-slate-800">Analytical Tradeoffs Matrix</h2>
          <p className="text-[10px] text-slate-400">Direct comparison of weighted positive and negative items</p>
        </div>
        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
      </div>

      <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pros Section */}
        <div className="space-y-3">
          <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest font-mono">Pros</p>
          {pros.length === 0 ? (
            <p className="text-xs text-slate-400 italic">No positive trade-offs identified.</p>
          ) : (
            <div className="space-y-2">
              {pros.map((pro, index) => (
                <div 
                  key={index} 
                  className="p-3 bg-emerald-50/50 rounded-xl text-xs sm:text-sm text-emerald-800 border border-emerald-100 flex items-start gap-2"
                >
                  <span className="font-bold text-emerald-600 mt-0.5 select-none">+</span>
                  <span>{pro}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Cons Section */}
        <div className="space-y-3">
          <p className="text-[10px] font-bold text-rose-600 uppercase tracking-widest font-mono">Cons</p>
          {cons.length === 0 ? (
            <p className="text-xs text-slate-400 italic">No warning signs or drawbacks identified.</p>
          ) : (
            <div className="space-y-2">
              {cons.map((con, index) => (
                <div 
                  key={index} 
                  className="p-3 bg-rose-50/50 rounded-xl text-xs sm:text-sm text-rose-800 border border-rose-100 flex items-start gap-2"
                >
                  <span className="font-bold text-rose-500 mt-0.5 select-none">-</span>
                  <span>{con}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

