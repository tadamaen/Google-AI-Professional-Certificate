/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Award, ShieldAlert, BadgeCheck, CheckCircle } from "lucide-react";
import { TiebreakerVerdictData } from "../types";

interface VerdictDisplayProps {
  verdict: TiebreakerVerdictData;
}

export function VerdictDisplay({ verdict }: VerdictDisplayProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-600 bg-emerald-50 border-emerald-200 fill-emerald-500";
    if (score >= 50) return "text-amber-500 bg-amber-50 border-amber-200 fill-amber-500";
    return "text-indigo-500 bg-indigo-50 border-indigo-200 fill-indigo-500";
  };

  const getScoreProgressColor = (score: number) => {
    if (score >= 80) return "bg-gradient-to-r from-emerald-400 to-emerald-600";
    if (score >= 50) return "bg-gradient-to-r from-amber-400 to-amber-500";
    return "bg-gradient-to-r from-indigo-400 to-indigo-600";
  };

  return (
    <div id="verdict-card" className="bg-slate-900 text-white rounded-2xl p-6 md:p-8 shadow-md border border-slate-800 relative overflow-hidden">
      {/* Decorative accent background circles */}
      <div className="absolute right-0 top-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
      <div className="absolute left-1/3 bottom-0 w-48 h-48 bg-emerald-600/5 rounded-full blur-2xl -ml-16 -mb-16 pointer-events-none" />

      <div className="relative flex flex-col md:flex-row md:items-start justify-between gap-6">
        <div className="space-y-4 md:max-w-[70%]">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-medium tracking-wider uppercase text-emerald-400 bg-emerald-400/10 border border-emerald-400/20">
            <Award className="w-3.5 h-3.5" />
            Decision Recommendation
          </div>
          
          <h3 id="recommendation-title" className="text-2xl md:text-3xl font-display font-semibold tracking-tight text-white leading-tight">
            {verdict.recommendation}
          </h3>

          <div className="space-y-2 mt-4 text-slate-300">
            <h4 className="text-xs font-mono text-slate-400 uppercase tracking-widest flex items-center gap-1 pb-1 border-b border-slate-800">
              <CheckCircle className="w-3.5 h-3.5 text-indigo-400" />
              Strategic Reasoning
            </h4>
            <p className="text-sm md:text-base leading-relaxed font-sans text-slate-300">
              {verdict.reasoning}
            </p>
          </div>
        </div>

        {/* Confidence Gauge Panel */}
        <div className="w-full md:w-56 shrink-0 bg-slate-800/60 p-4 md:p-5 rounded-xl border border-slate-700/50 flex flex-col items-center justify-center text-center">
          <span className="text-xs font-mono tracking-widest uppercase text-slate-400">
            AI Confidence
          </span>
          
          <div className="relative mt-3 flex items-center justify-center">
            {/* Simple elegant circular or numeric display */}
            <div className="text-4xl md:text-5xl font-display font-bold text-white tracking-tighter">
              {verdict.confidenceScore}%
            </div>
          </div>

          <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden mt-3.5">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ${getScoreProgressColor(verdict.confidenceScore)}`} 
              style={{ width: `${verdict.confidenceScore}%` }}
            />
          </div>

          <div className="flex items-center justify-between w-full mt-2 text-[10px] font-mono text-slate-500">
            <span>UNSURE</span>
            <span>BALANCED</span>
            <span>DEFINITIVE</span>
          </div>
          
          <div className="mt-4 flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 text-xs">
            <BadgeCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="line-clamp-1">Objective evaluation</span>
          </div>
        </div>
      </div>
    </div>
  );
}
